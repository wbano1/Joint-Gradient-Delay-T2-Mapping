function [z,T2_map, PD,obj] = ALS_TVmo(y,csm,param)
%
% Implememnting ALternating Least square for finding output and theta
% iteratively
% min_{x,Theta} 1/2|y-E(x)|^2 + lambda1 /2 |x-f(Theta)|^2  + lambda2 * TV(x)
% Mo and Wajiha 6-07-2017

%input:

%y= data in a vector form with only the acquired samples
%csm= sensitivity maps- 4D matrix with size NX,NY,NT,NC
%samp_mat= Sampling Pattern 4D same dim as sensitivity Maps
%reg= regularizer either empty or a 3D matrix SOS combined image
%lambda= regularizer
%TE- Numver of echoes
% iterations- Number of iterations

%output
%z= Reconstructed Image
%T2_map
%PD- Proton density
%coeff_1= phase
%coeff2=time varying frequency
%obj= error
%%
[nx,ny,nt,nc]=size(y);

param.E=MCNUFFT(double(param.k),double(param.w),csm);
TE=param.TE;
% param.E = Emat_xyt(samp_mat,csm); % multicoil model (b1: coil sensitivities)

param.nite = 20; %fista max iterations
param.y=double(y);

% linear reconstruction
param.z=param.E'*(param.y.*sqrt(param.w));
% param.z=zeros(size(param.z));
temp =param.lambda;
%  param.init = repmat([65,500],nx,1,ny);
% param.init=permute(param.init,[1,3,2]);
%% ----warm-up: FISTA SENSE ----
% param.lambda = 0;
% param.step = 5;
% param.x0 = fista_sense(param);
% [T2_map, PD,  param.z]=log_lin(param.x0,TE);
% 
% figure
% imagesc(abs(param.z(:,:,8))); colormap gray; drawnow

% param.init = cat(3,T2_map,PD);
%% ----ALS loop----
param.lambda = temp;
for i =1:param.iter
    
    fprintf('***********************************');
    fprintf('ALS iter=%i',i);
    fprintf('***********************************\n');
    
    %step1: data consistency
    param.x0 = fista_sense(param);
    %step 2: model consistency

    [T2_map, PD,  param.z]=log_lin(param.x0,TE);

 param.init = cat(3,T2_map,PD);
    imagesc(abs(param.z(:,:,8))); colormap gray; drawnow
    %imshow(abs(param.z(:,:,8)),[]),colorbar, title(['iter',num2str(i)]);    
    obj = [];
    % xx=param.y-param.E*(x);
    % obj(i) = 1/2* norm( xx(:).^2 )+param.lambda/2 *norm(x(:) -param.z(:))^2;
    %
    
    %
    % %     if (obj(i)-obj(i+1))/ obj(i) < 1e-04
    % %         break
    % %     end
end
z=param.z;

end
