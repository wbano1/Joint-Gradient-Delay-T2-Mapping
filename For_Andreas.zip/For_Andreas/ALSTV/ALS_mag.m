function [z,T2_map, PD, obj,r2] = ALS_mag(y,csm,TE,param)

% Implememnting ALternating Least square for finding output and theta
% iteratively
% min_{x,Theta} 1/2|y-E(x)|^2 + lambda/2 |x-f(Theta)|^2
% Mo and Wajiha 6-07-2017
%     param.k = param.k.*400./size(csm,1);

if param.GPU % AW_EDITSs
    % build the NUFFT (Greengard separable Gaussian kernel)
%     p.wi=reshape(p.wi,size(k,1),1);ans(1)
     param.E = MCNUFFT_gpuNUFFT(double(param.k),double(param.w),csm);
%     G=gpuNUFFT(double(k'),ones(size(p.wi)), 1.5, 5, 16,[p.dim p.dim],[]);
else
%     k=complex(k(:,1),k(:,2));
%     k=reshape(k,[p.npts,p.nproj]);
%     %p.wi=reshape(p.wi,size(k,1),1);
      param.E = MCNUFFT(double(param.k),double(param.w),csm);
%           G = NUFFT(updatedk(:,:,1), p.wi(:,:,1),1, [0,0], [p.dim p.dim], 2);

%     %G = NUFFT(k, p.wi,1, [0,0], [p.dim p.dim], 2);
%     G = NUFFT(k, ones(size(p.wi)),1, [0,0], [p.dim p.dim], 2);
end

% param.E=MCNUFFT(double(param.k), double(param.w),csm);
lambda=param.lambda;
iter=param.iter;
% TE=TE./1000;
% linear reconstruction
z=param.E'*((y).*sqrt(param.w));
% [T2_map, PD,  z]=log_lin(param.z,TE);
% for i=1:length(TE); z(:,:,i)=param.M.*exp(-TE(i).*param.R); end
%   param.Nx = size(z,1); param.Ny=size(z,2);


E = @(x,tr)ismrm_encoding_noncartesian_SENSE(x,param.w,param.E,csm,tr);
B = @( x ,~) E( E( x ,'notransp'),'transp') + lambda * x(:) ;

% z=ismrm_cartesian_iterative_SENSE(y,samp_mat,csm,reg,replicas);
%   z=zeros(size(param.z));
%   Nx = size(z,1);Ny=size(z,2);

for i =1:iter
    %Step 1 of Alternating minimization
u = E(y,'transp')+lambda.*z(:);
x= lsqr(B,u,1e-4,100);
x = reshape(x,size(z));
    %Step 2
[T2_map, PD, z,r2]=log_lin(x,TE);
figure(1), imagesc(T2_map,[0 90]),colorbar,title(['iter ', num2str(i)])

obj(i) = 1/2* norm( y(:)-E(x,'notransp'))^2 +lambda/2 *norm(x(:) -z(:))^2;
fprintf('iter=%i, Obj=%e\n',i,obj(i));
%     
%         if obj(i-1)- obj(i)/ obj(i) <  tol 
%         break;
%         end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end