function [T2_map,PD,coeff_1,coeff_2, x_recon]= NLS(Img_array,te,param)

%% Non Linear Least Square SOlver
%This functions takes the Input Image and perform NLLS on the complex data
%to give parametric Maps. This is particularly for the Image solved by
%SENSE so its dimensions is Nx,Ny,T

%----admisible regions---- 
%lb=[0,-0.5,-.5,0]; %Lowerbound
lb=[5,-4,-0.5,20]; %Lowerbound
ub=[500,4, 0.5,1e05];  %Upperbound

%ub=[520, 2*pi, 0.5,120];  %Upperbound

%---sizes
[Nx,Ny,Nt] = size(Img_array);
mc_imgfull = abs(squeeze(Img_array(:,:,1))); %sos
mask = repmat(get_mask(mc_imgfull),1,1,Nt);
T2_map = zeros(Nx,Ny);
PD = zeros(Nx,Ny);
x_recon = zeros(Nt,Nx,Ny);
coeff_1 = zeros(Nx,Ny);
coeff_2 = zeros(Nx,Ny);
Img_array = mask.*Img_array;
tic
for nx= 1:Nx
    for ny=1:Ny
         if (abs(Img_array(nx,ny,1)) > 0)
          
           %[65,0.9,-0.07,100]; % Initialization 
            y=squeeze(Img_array(nx,ny,:));  % 8x8 matrix  
             x0 = [param.init(nx,ny,1),param.init(nx,ny,2),param.init(nx,ny,3),param.init(nx,ny,4)]; %#ok<PFBNS>
            ydata2=[real(y); imag(y)];            
            xdata=te';    %8x8
            
            options = optimoptions(@lsqcurvefit,'Display','Off','MaxFunctionEvaluations', 10000, 'MaxIterations',10000);
            % % %
            [x,resnorm,residuals,exitflag,output] = ...
                lsqcurvefit(@cplxreal,x0,xdata,ydata2,lb,ub,options);

            T2_map(nx,ny)=x(1);
            PD(nx,ny)=x(4);
            coeff_1(nx,ny)=x(2);
            coeff_2(nx,ny)=x(3);

            Recon_image_m=cplim(x,xdata);
            x_recon(:,nx,ny)= Recon_image_m.';
         end
    end
end
toc
x_recon = permute(x_recon,[2,3,1]);
end