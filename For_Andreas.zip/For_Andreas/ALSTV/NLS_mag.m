function [T2_map, PD, Recon_image]=NLS_mag(Img_array,te)
%% Non Linear Least Square SOlver
%This functions takes the Input Image and perform NLLS on the Magnitude
%Data to give parametric Maps. This is particularly for the Image solved by
%SENSE so its dimensions is Nx,Ny,T
% wajiha Bano 21-08-2017
%Sizes
[Nx,Ny,Nt]=size(Img_array);
mask=repmat(get_mask(abs(Img_array(:,:,1))),1,1,Nt);
T2_map=zeros(Nx,Ny);
PD=zeros(Nx,Ny);
Recon_image=zeros(Nt,Nx,Ny);
Recon_image_m=zeros(1,Nt);
Img_array=mask.*Img_array;
tic
 for nx=1:Nx
     for ny=1:Ny
         if (abs(Img_array(nx,ny,1)) > 0)

           y=abs(squeeze(Img_array(nx,ny,:))); % 8x8 matrix
%           phase=angle(squeeze(Img_array(nx,ny,:)));
          x_data=te; 
          funct = @(x)x(2).*exp(-x_data./x(1)) - y';  %define function
          x0 = [0,0];
          lb=[0,-inf];
          ub=[300,5];
            
          options = optimset('Display', 'off');
           x = lsqnonlin(funct,x0,[],[],options);
%       
            T2_map(nx,ny)=x(1);
             PD(nx,ny)=x(2);

                 for k=1:length(te)
                Recon_image_m(k)=x(2).*exp(-te(k)./x(1));
                           
                 end
%              Recon_image(:,nx,ny)= Recon_image_m'.*exp(1i*phase);
         end
     end
 end
 toc

    Recon_image=permute(Recon_image,[2,3,1]);
end