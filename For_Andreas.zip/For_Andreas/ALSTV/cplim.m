function yout = cplim(x,xdata)
% This function takes input from the NLLS solver and output the complex
% response

tmpR =x(4)*exp(-xdata./x(1)).*cos(x(2)-(x(3)*xdata));
tmpI =x(4)*exp(-xdata./x(1)).*sin(x(2)-(x(3)*xdata));
yout=complex(tmpR,tmpI);