function yout = cplxreal(x,x_data)
% Function that outputs the real and Imaginary parts of data by inputing.
% The functions goes into NLLS solver to minimize
% the initial parameters x
%x(4)=PD
%x(3)=Time dependant Phase
% x(2)= Constant Phase
% x(1)= T2
tmpR =x(4).*exp(-x_data./x(1)).*cos(x(2)-(x(3)*x_data));
tmpI =x(4).*exp(-x_data./x(1)).*sin(x(2)-(x(3)*x_data));
yout = [tmpR(:);tmpI(:)];

