function x = fista_sense(param)

if ~isfield(param, 'nite'), param.nite = 5; end
if ~isfield(param, 'tol'), param.tol = 1e-3; end
if ~isfield(param, 'step'), param.step = 10; end
if ~isfield(param, 'GPU'), param.GPU = 0; end
if ~isfield(param, 'backtrack'), param.backtrack = 1; end
if ~isfield(param, 'step'), param.step = 10; end
if ~isfield(param, 'x0'), param.x0 = zeros(size(param.z)); end
max_iter = param.nite;
tol = param.tol;

[N,M,L] =  size(param.z);
step = param.step;
paramtv.useGPU=param.GPU;
paramtv.verbose = 0;

x = param.x0;
x2_prev = x;
obj_prev = 0;
%% FISTA for Wavelet L1

for i = 1:max_iter
    
 
    grad1 = param.E'*((param.E*x).*sqrt(param.w))+ param.lambda*(x - (param.E'*(param.y.*sqrt(param.w)))) - param.lambda* param.z;
%    grad1 = (param.E'*(param.E*x))+param.lambda*x -  (param.E'*param.y) - param.lambda* param.z;
    %cvxobj = 1/2*norm(err(:))^2 ;
    cvxobj = 1/2* norm(reshape(param.E*x - param.y,[],1))^2 + 1/2*param.lambda*norm(x(:)-param.z(:))^2;  
    %[val] = wavethresh_group(x, []);
    
    val = norm_tv([reshape(real(x),N,[]); reshape(imag(x),N,[])] );
    
    %---------backtracking line search
    done = 0;
    while ~done
        x2    =   x - grad1 * step;
        %[~,x2]=  wavethresh_group(x2, step*param.K);
        
        if param.TV>0
        x2  = [reshape(real(x2),N,[]); reshape(imag(x2),N,[])];
        [x2,~] = prox_tv(x2, step*param.TV, paramtv); 
        x2 = x2(1:N,:) +1j*x2(N+1:end,:);
        x2 = reshape(x2,N,M,[]);
        end
        
        %tmp = 1/2*(norm( reshape(F.forward(x2) - y,[],1))^2   +   rho* norm(x2(:)-z(:)+u(:))^2 );
        
        if ~ param.backtrack
            done = 1;
        else
            tmp = 1/2* norm(reshape(param.E*x2 - param.y,[],1))^2 + 1/2*param.lambda*norm(x2(:)-param.z(:))^2;              %norm( reshape(F.forward(x2) - y,[],1))^2;
            if (tmp > cvxobj +  real( grad1(:)'*(x2(:)-x(:)))  + 1/(2*step) * norm(x2(:)-x(:))^2)
                disp('reducing stepsize...');
                step = step/2;
            else
                done = 1;
            end
        end
    end
 
    %----------------------   
    obj = cvxobj + param.TV*val;
    fprintf('=== Iter=%i, Obj_FISTA: |y-Ax|^2  + beta*TV(x) + lambda*|x-z|  =%e\n', i,obj);
    
    if i>1 && ( abs(obj_prev-obj)/obj <tol || (obj_prev-obj)<0 ); break;end
    obj_prev = obj;
    
    %----------------------
    x     =   x2 + (i-1)/(i+2)* (x2-x2_prev);    
    x2_prev = x2;
end