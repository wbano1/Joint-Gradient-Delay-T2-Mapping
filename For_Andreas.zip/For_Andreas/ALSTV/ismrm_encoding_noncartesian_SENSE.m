function y =  ismrm_encoding_noncartesian_SENSE(x,wi,E,csm,transp_flag)
Nx=size(wi,1);
 Ny=size(wi,2);
 Nc=size(csm,3);
 Ne=size(wi,3);
if (strcmp(transp_flag,'transp'))
 
 x=reshape(x,[Nx,Ny,Nc,Ne]);
 for tt=1:Ne
        for ch=1:Nc
            b = x(:,:,ch,tt).*sqrt(wi(:,:,tt));
            res(:,:,ch,tt) = b;
        end
 end
   y=E'*(res);
%     y = sum(conj(csm) .* y,3);
    y = y(:);
elseif (strcmp(transp_flag, 'notransp'))
 y1 = reshape(x,size(csm,1),size(csm,2),Ne);
%     outp = ft(outp, [1,2]);
    y1=(E*y1);
  for tt=1:Ne
        for ch=1:Nc
            b = y1(:,:,ch,tt).*sqrt(wi(:,:,tt));
            res(:,:,ch,tt) = b;
        end
 end
%     y1=y1.*repmat(sqrt(wi),[1 1 1 size(y1,4)]);
    y=res(:);
else
    error('Transpose flag not appropriately defined');
end 
end

 