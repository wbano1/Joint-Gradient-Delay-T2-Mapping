function [T2_map, PD,  Recon_image,r2]=log_lin(x,te)

[Nx,Ny,Nt] = size(x);
mc_imgfull = abs(squeeze(x(:,:,1))); %sos
mask = repmat(get_mask(mc_imgfull),1,1,Nt);
% x = mask.*x;


        y=abs(x); % 8x8 matrix
         phase=angle(x);
          x_data=te./1000; 
        r2 = arlo(x_data,y);
         maps=r2PixelFit(y,te);
          PD=maps(:,:,2);
          T2_map=1./maps(:,:,1);
          
            for k=1:length(te)
                z(:,:,k)=PD.*exp(-te(k)./T2_map);
%                 z(:,:,k)=PD.*exp(- x_data(k).*r2);
             
            end
            
            Recon_image= z.*exp(1i*phase);
              T2_map(isnan(T2_map))=0;
            PD(isnan(PD))=0;
            Recon_image(isnan(Recon_image))=0;
            r2(isnan(r2))=0;

end

          
          
          