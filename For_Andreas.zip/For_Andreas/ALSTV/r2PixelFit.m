%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Log linear regression
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function map = r2PixelFit(IMG, TE)
% usage: map = r2PixelFit(IMG, TE)
%
% creates spin-density and R2 map by standard fitting
%
% IMG : T2 weighted images with size(IMG) = [dimY, dimX, NE]  (NE being the
% number of echoes)
%
% TE  : echo time vector 
%
% map : parameter maps with size(map) = [ dimY, dimX, 2 ].
%       map(:,:,1) : R2 map
%       map(:,:,2) : spin-density map

[dimY, dimX, NE] = size(IMG);

% make sure that TE is a column vector
TE = reshape(TE,[1,length(TE)]);


% reshape tensor to a 2D matrix
dimN = dimX * dimY;
IMG  = reshape(IMG,[dimN, NE]);

% allocate memory for the fit result
R2 = zeros(dimN,1);
Rho = zeros(dimN,1);

% do the fitting
parfor n = 1 : dimN
%         % Standard
%         M = IMG(n,:);
%         lny = 0;
%         x2 = 0;
%         x = 0;
%         xlny = 0
%         N = numel(M);
%         for i = 1:N;
%             lny  = lny + log(M(i));
%             x2   = x2 + TE(i)^2;
%             x    = x + TE(i);
%             xlny = xlny + TE(i) * log(M(i));
%         end
%         Rho(n) = exp( ( lny * x2 - x *xlny ) / ( N * x2 - x^2 ) );
%         R2(n)  = -( ( N * xlny - x * lny  ) / ( N * x2 - x^2 )  );

        % M0 weighted
        M = IMG(n,:);
        x2y = 0;
        ylny = 0;
        xy = 0;
        xylny = 0;
        y = 0;
        for i = 1:numel(M);
            x2y = x2y + (TE(i)^2) * M(i);
            ylny = ylny + M(i) * log(M(i));
            xy = xy + TE(i) * M(i);
            xylny = xylny + TE(i) * M(i) * log(M(i));
            y = y + M(i);
        end
        Rho(n) = exp( ( x2y * ylny - xy * xylny ) / ( y * x2y - (xy^2) ) );
        R2(n)  = -( ( y  * xylny - xy * ylny  ) / ( y * x2y - (xy^2) ) );

end
map = cat(2,R2,Rho);

% reshape fit result
map = reshape(map,[dimY,dimX,2]);                        

end

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % Non-Linear Least Squares Fit
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% function map = r2PixelFit(M, TE)
%     M = squeeze(M);
%     if(size(TE,1) == 1)
%         TE = TE';
%     end
%     options = optimset('Display','off','MaxIter',5,'TolFun',1e-6,'Jacobian','on');
%     R2 = 0.08;
%     M0 = 1;
%     x0 = [R2;M0];
%     map = zeros(size(M,1),size(M,2),numel(x0));
%     for y = 1:size(M,1);
%         parfor x = 1:size(M,2);
%             dat = reshape(M(y,x,:),[numel(TE) 1]);
%             map(y,x,:) = lsqnonlin(@(x)fun(x, TE, dat), x0 , [] , [], options);
%         end
%     end
% end
% 
% function [F J] = fun(x, TE, M)
%     e = exp(-TE.*x(1));
%     F = x(2).*e - M;
%     J = [-TE.*x(2).*e,e];
% end

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % Linaer Least Squares Fit
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% function map = r2PixelFit(M, TE)
%     lnM = squeeze(log(M));
%     dataSize = size(lnM);
%     imSize = [dataSize(1),dataSize(2)];
%     TE2D = repmat(reshape(TE,[1 1 numel(TE)]),imSize);
% 
%     b = lnM(:);
%     
%     map = lsqr(@(x,tflag)afun(x, dataSize, imSize, TE2D, tflag), b );
%     map = reshape(map,[imSize(1),imSize(2),2]);
%     map(:,:,2) = exp(map(:,:,2));
% end
% 
% % pseudo-matrix to solve cost function ||( ln(M0) - TE * R2 ) - ln(M)||
% function [y, tflag] = afun(x, dataSize, imSize, TE, tflag)
%     if strcmp(tflag,'transp')
%         y = reshape(x,dataSize);
%         
%         R2 = sum(-TE.*y,3);
%         lnM = sum(y,3);
%         y = [R2(:);lnM(:)];
%     else
%         R2   = reshape(x(1:prod(imSize)),imSize);
%         lnM0 = reshape(x(prod(imSize)+1:end),imSize);
%         lnM  = bsxfun(@minus,lnM0,ftimes(TE,R2));
%         y = lnM(:);
%     end
% end