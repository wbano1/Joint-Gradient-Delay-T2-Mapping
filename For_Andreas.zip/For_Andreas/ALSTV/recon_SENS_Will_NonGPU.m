function [z, T2_map, PD, img,flag,relres,iter,resvec,lsvec, param] = recon_SENS_Will_NonGPU(data,imginit,niteri,wi,G,SENSEmap,yALS,csm,TE,param,p)
% reconstruct an image from non-Cartesian acquisitions, using SENSE

%data       =   initial k-space data (must be a double!)
%imginit    =   initial image
%niteri     =   number of lsqr iterations
%wi         =   density weights
%G          =   NUFFT object (set with Gnufft)
%SENSEmap   =   map of coil sensitivities (must be a double!)

param.lambda =1; %Regularization parameters
%param.E=MCNUFFT_gpuNUFFT(double(param.k), double(param.w),csm);
param.E=MCNUFFT(double(param.k), double(param.w),csm);
lambda=param.lambda;
z=param.E'*((yALS).*sqrt(param.w));

E = @(xALS,tr)ismrm_encoding_noncartesian_SENSE(xALS,param.w,param.E,csm,tr);
B = @( xALS ,~) (E( E( xALS ,'notransp'),'transp') + lambda * xALS(:)) ;
%%
    %Step 1 of Alternating minimization
u = E(yALS,'transp')+lambda.*z(:);
xALS= lsqr(B,u,1e-4,100);
xALS = reshape(xALS,size(z));
    %Step 2
[T2_map, PD, z]=log_lin(xALS,TE);
%zreshaped = reshape(z,p.dim,p.dim,[]);
%zreshaped = sqrt(sum(abs(zreshaped).^2,3)).';
%figure('Name','z TrACR Image'), imagesc(zreshaped,[0 90]),colorbar,title('z TrACR Image');
%saveas(gcf,'z_TrACR_Image.png'); %Save figure to see progress
as(z)
obj = 1/2* norm( yALS(:)-E(xALS,'notransp'))^2 +lambda/2 *norm(xALS(:) -z(:))^2;
fprintf('Obj=%e\n',obj);

%%
SENSEmap = SENSEmap(:);
N = numel(imginit);     %number of image points
imSize = size(imginit); %image size
dataSize = size(data);  %k-space data size

b = data(:).*repmat(sqrt(wi(:)),[length(data(:))/length(wi(:)) 1]);
wi=sqrt(wi(:));
if ~exist('tol','var')
    tol=1e-6;
end
%perform least-squares recon

[img,flag,relres,iter,resvec,lsvec] = lsqr(@(x,transp_flag)afun(x,wi,dataSize,imSize,G,SENSEmap,transp_flag), b, tol, niteri,speye(N,N),speye(N,N), imginit(:));

img = reshape(img,imSize);





function [y, transp_flag] = afun(x,wi,dataSize,imSize,G,SENSEmap,transp_flag)
if strcmp(transp_flag,'transp')

    %reshape to orig data size
    x1 = reshape(x(1:prod(dataSize)),dataSize);
    numcoils = dataSize(end);
    y = zeros([imSize, numcoils]);
    parfor ii = 1:numcoils
        %type I NUFFT
        y(:,:,ii) = reshape(G'*(wi.*x1(:,ii)),imSize);

    end
    y = y(:);
    y = conj(SENSEmap).*y;
    y = reshape(y,[prod(imSize),dataSize(end)]);
    y = sum(y,2);

else

    xt=SENSEmap.*repmat(x,[dataSize(end) 1]);
    xt=reshape(xt,[imSize dataSize(end)]);
    numcoils=dataSize(end);
    y1=zeros(dataSize);
    parfor ii = 1:numcoils
        xtall = xt(:,:,ii);
        %type II NUFFT
        y1(:,ii)=wi.*col(G*xtall(:));
    end
    y = y1(:);

end

function out = col(in)

out = in(:);
