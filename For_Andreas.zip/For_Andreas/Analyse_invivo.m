clc
clear
%close all
clear
addpath(genpath('M:\functions\'))
addpath(genpath('M:\gpuNUFFT-master\radia_t2star_mapping\'))
folder ='M:\MRinRT20\MR-LINAC\20191024_prostate_miga\raw\';
% 'C:\Users\wbano\Documents\DATA\12_Nov\MiGa\';
factor=1;
[kdata_i,recon_comb,b1,param] = invivo(folder,factor,'Uniform');
clear param.E
param.TE=5:5:40;
param.lambda = 1; % Regularizer for Model-consitency
param.iter=5; % Number of iterations
factor=1;
slice=22;
kdata_i=squeeze(double(zf_raw(:,:,slice,:,:)));
param.k=knom;
param.k=param.k.*400./384;
param.w=p.wi;
param.GPU=1;
% [z,T2_map, PD, obj] = ALS_TVmo(kdata_i,squeeze(b1(:,:,:,1)),param); %Old Wajiha's version
[img_ALS,T2_ALS, PD_ALS, obj,R2] = ALS_mag(kdata_i,squeeze(b1),param.TE,param); %Run the code
%%
% Demo Trajectory Auto-Compensation Reconstruction (TrACR)for radial k-space trajectories
%=========================================================================================
% knom=param.k; % first echo only %BW
% knom(:,:,2:2:end)=knom(:,:,2:2:end)*-1;
% knom = knom / (size(knom, 1) / 2 / p.dim);
p.npts = size(knom,1); % number of points per radial line
p.nproj = size(knom,2); % number of radial projections
p.ncoils = size(kdata_i,3); % # Rx coils p.knom = [real(knom(:)) imag(knom(:))];   % nominal k-space trajectory form, cycles/cm [# points per projection x # projections]
p.echo=size(kdata_i,4);
% TrACR parameters---------------------------------------------------------
p.dim =268;     % matrix size, 1D (2nd assumed equal)
p.fov = 400;    % field of view in cm
% data=squeeze(kus(:,:,:,1)); % focussing on first echo WB
% p.data = reshape(data,[(p.npts*p.nproj),p.ncoils]);   % k-space data in: [(# readout pts * shots) X # coils]

% the k-space positions must be scaled according to the resolutions:
%knom = knom / (size(knom, 1) / 2 / p.dim); % two is for readout oversampling...
for i=1:p.echo
    temp=knom(:,:,i);
    p.knom(:,:,i) = [real(temp(:)) imag(temp(:))];
end
% nominal k-space trajectory form, cycles/cm [# points per projection x # projections]
% p.usedc = 1;     % use density compensation
p.maxiters = 100;  % maximum # of outer iterations to run TrACR
p.niteri = 2;    % # of iterations per image update
p.niterk = 5;    % # of iterations per kspace update
% p.imgcart = imgcart;    % Cartesian image from which to derive coil sensitivities
p.reconalg = 'SENSE'; % use SENSE image reconstruction (TrACR can also do SPIRiT if the correct parameters are passed)

p.useGPU =true; % AW_EDIT whether to use GG NUFFT or not ... 
p.useInitialGuess = true; % AW_EDIT whether to use non-zero initial guess ...
% [x, y] = ndgrid(-0.5:1/p.dim:0.5-0.5/p.dim);
  [x,y] = ndgrid(-p.fov/2:p.fov/p.dim:p.fov/2-p.fov/p.dim);
p.x = x(:);
p.y = y(:);

% density compensation weights: for GA radial, approximate as |kx+1i*ky|
% if p.usedc
% %    
% %         p.wi = abs(p.knom)./max(abs(p.knom));
% p.wi = abs(p.knom(:,1) + 1i*p.knom(:,2))./max(abs(p.knom(:,1) + 1i*p.knom(:,2)));
%     p.wi(isnan(p.wi))=1;
%     p.wi(isinf(p.wi))=1;
%     p.wi(p.wi == 0) = 1/2/size(knom, 1); % AW_EDIT
% % else
% %     p.wi = 1;
% end
% p.wi=wi(:);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% set up k-space error basis (for radial)
% Assumption: The k-space errors comprise shifts of each line in kx-ky
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fprintf('Setting up error basis...\n');
eb = kron(speye(p.nproj),ones(p.npts,1));
p.eb = [eb 0*eb;0*eb eb]; % k-traj error basis (npts*nproj*(kx + ky) x nproj)

%%%%%%%%%%%%%%%%%%%%%%%%
% estimate sensitivites
%%%%%%%%%%%%%%%%%%%%%%%%
% fprintf('Estimating Sensitivities...\n');
% sosimg = sqrt(sum(abs(p.imgcart.^2),3));
% sens = double(p.imgcart./repmat(sosimg,[1 1 p.ncoils]));
%  p.SENSEmap = double(squeeze(b1(:,:,slice,:)));
%   p.SENSEmap=squeeze(b1);
%%%%%%%%%%%%%%%%%%%%%%%%%
%run TrACR----------
%%%%%%%%%%%%%%%%%%%%%%%%%
p.wi=param.w;
p.lambda=0.5;
for slices= 15:35
 p.SENSEmap=squeeze(b1(:,:,slices,:));
kdata_i=squeeze(zf_raw(:,:,slices,:,:));
% [img_TrACR,c_TrACR,cost,imgsv,csv,p] = TrACR_sequential_odd_even_new(kdata_i,p);
[T2_TrACR_ALS, PD_TrACR_ALS,img_TrACR_ALS,c_TrACR_ALS,cost,imgsv_t,csv,p,param] = TrACR_ed_Will_GPU_odd_even(kdata_i,p,param);
% [T2_TrACR, PD_TrACR, img_TrACR]=log_lin(img_TrACR,param.TE);
end

% [T2_TrACR_ALS, PD_TrACR_ALS,img_TrACR_ALS,c_TrACR_ALS,cost,imgsv_t,csv,p_TrACR_ALS,param] = TrACR_ed_Will_GPU_odd_even(kdata_i,p,param);

display_TrACR_result(p_TrACR_ALS,c_TrACR_ALS,imgsv_t,img_TrACR_ALS,cost)

%% TrACR Only Followed by non-linear least square

param.TE=5:5:40;
[img_TrACR,c_TrACR,cost,imgsv,csv,p,param] = TrACR_sequential_odd_even(kdata_i,p,param);
for kk=1:p.ncoils %WB 01/08
    % reconstruct estimated total k-space trajectory
    k_temp = p.knom(:,:,kk);
    k_temp= k_temp + reshape(p.eb*c_TrACR(:,kk),size(p.knom(:,:,1)));
    updatedk(:,:,kk)= reshape(complex(k_temp(:,1),k_temp(:,2)),[p.npts,p.nproj]);
end

for ii=1:8
    k_phase(:,:,:,ii)=radial_phase_correction_model(kdata_i(:,:,:,ii),updatedk(:,:,ii));
end
k_u=updatedk.*p.fov./512;
param.E=MCNUFFT(double(k_u), double(p.wi), b1);

im_i = param.E'* (k_u .* sqrt(p.wi));

as(im_i)
[T2_TrACR, PD_TrACR, img_TrACR]=log_lin(img_TrACR,param.TE);
display_TrACR_result(p,c_TrACR,imgsv,img_TrACR,cost)

