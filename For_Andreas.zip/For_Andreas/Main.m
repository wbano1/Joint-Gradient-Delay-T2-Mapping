clear 
close all
addpath(genpath('F:\Wajiha\For_Andreas\For_Andreas'))



Patient_dir=('F:\Wajiha\CCR4841_PER058\20201117');
list=dir(Patient_dir);

for a= 3:numel(list)
folder = [Patient_dir,'\', list(a).name];
display(['Reconstructing' , list(a).name])
T2_map= reconstruct_T2(folder);
DICOM_folder = [Patient_dir,'\', list(a).name,  '\SCANS\403\DICOM'];
outputfolder = save_dicoms (folder, DICOM_folder, interpt);
end


Read_Write_contours('F:\Wajiha\test_268\20201117\', 'F:\Wajiha\test_268\20201117\T2') 

 