function Read_Write_contours(path_to_contourfile, path_to_R2) 
%% Now Read R2* Map

% Select the contour R-struct
disp('=================Select the R-struct contour file===================')
% path_to_contourfile= ('M:\gpuNUFFT-master\radia_t2star_mapping\For_Andreas\Test_data\16.03');
rfile = dir([path_to_contourfile '/*.dcm']);
contour_info=dicominfo(rfile.name);
resultfolder = [path_to_contourfile, '\Results'];

if ~exist(resultfolder, 'dir')
  mkdir(resultfolder);
end

filename = [resultfolder '/'  'myfile'];

dicomlist= dir([path_to_R2 '/*.dcm']);
locations = [];


for a = 1:numel(dicomlist)
   info = dicominfo([path_to_R2 '/' dicomlist(a).name]);
%   data = dicomread([path_to_R2 '/' list(a).name]);
% %   
       if ~any(locations == info.SliceLocation)
     locations = [locations info.SliceLocation];
    headers(locations == info.SliceLocation).info = info;
       end
R(:,:,locations == info.SliceLocation)=dicomread([path_to_R2 '/' dicomlist(a).name]);
      disp(['Reading file',info.SeriesDescription, info.StudyDate]); %to check if same series is being read
 %to check if same series is being read
%           c=c+1;  
pixel_r = info.PixelSpacing;
orient_r(:,locations == info.SliceLocation) = info.ImagePositionPatient;
slicedist_r= info.SliceThickness;
   
end
    [sliceloc, I] = sort(locations,'descend');
    data(:, :, :) = R(:, :, I);
    orient_r(:, :) = orient_r(:, I);
%      [sliceloc, I] = sort(locations, 'descend')
    slicedist_r = median(orient_r(3, 2:end) - orient_r(3, 1:end-1)); 
    position_r= orient_r(:,end);

    pixelspc_r = [pixel_r;slicedist_r];
%Interpolate the R to match the size of f map
% [rows,cols,slices] = size(R);
% [X,Y,Z] = meshgrid(c + (0:cols-1) * pixelspc_r(1), position_r(2) + (0:rows-1) * pixelspc_r(2), position_r(3) + (0:slices-1) * pixelspc_r(3));
% [X2,Y2,Z2] = meshgrid(position_r(1) + (0:size(R,1)-1) * pixelspc_r(1), position_r(2) + (0:size(R,2)-1) * pixelspc_r(2), position_r(3) + (0:size(R,3)-1) * pixelspc_r(3));
% out = interp3(X, Y, Z, double(data), X2, Y2, Z2, 'cubic');
%visualise the interpolated map
% as(out)
%     contour_info=dicominfo('RS1.2.752.243.1.1.20211118105710840.3300.58513.dcm');
    rtContours = dicomContours(contour_info);  
    ROIs=rtContours.ROIs;
    mask=zeros(size(R));
       for  contourIndex =1:length(ROIs.Number)
        [rtMask, contourName] = contourToMask(pixelspc_r, position_r, size(R), rtContours, ROIs.Number(contourIndex));
         Roi_data{:, contourIndex} = double(R(rtMask));
         mask=mask+rtMask;
       end       

as(flipud((mask.*500)+ double(R)));
% imagesc((mask(:,:,35).*1500)+ double(R(:,:,35)),[0 90]),colormap gray


write_xl_file(Roi_data,ROIs.Name,1,filename)
end
