function [T2_map, PD, img,c,cost,imgsv,csv,p,param] = TrACR_ed_Will_GPU_odd_even(data,p,param)

% correct for k-space trajectory errors and reconstruct an image
%
% data = k-space data (number of points x number of coils)
% p = parameter structure
%
% Copyright 2015, Julianna Ianni and Will Grissom, Vanderbilt University

% Do some argument processing
if ~isfield(p,'useparfor')
    p.useparfor = 0;
end
if ~isfield(p,'bls')
    p.bls = 1;
end

% initialize k-space error guess
if isfield(p,'cinit')
    c = p.cinit;
else
    c = zeros(size(p.eb,2),p.echo); % assume that x,y,z error coeffs are stacked end-on-end
end
    
fprintf('Starting TrACR...\n')
for tt=1:p.echo
    data(:,:,:,tt)= data(:,:,:,tt).*sqrt(p.wi(:,:,tt));
end
tti=tic; % time it

% do an initial recon of the image with the nominal kspace trajectory
G = buildG_odd_even(p,c);
[ T2_map, PD, img,param] = imgupdate_odd_even(p,G,data,param);
% img = imgupdate1(data,p,G);
% calculate initial cost:
cost = cost_eval_odd_even(data,img,p,G);
fprintf('Starting cost: %d ... \n', cost);

%save cost and img
csv(:,:,1) = c;
imgsv(:,:,:,1) = img;
keepgoing = 1;

while keepgoing % start alternation minimization loop
    fprintf('Working on iter # %d ...\n',length(cost))
    
    % update k-space error coefficients
    fprintf('Updating trajectory...');
 
    [c,cnn] = cupdate_odd_even(p,data,img,c);
    fprintf(' %d trajectory iterations taken...\n',cnn);
%     k_temp= p.knom + reshape(p.eb*c,size(p.knom));
    %updatedk= reshape(complex(k_temp(:,1),k_temp(:,2)),[p.npts,p.nproj]);
%     figure,plot(updatedk);
    % setup NUFFT with the new error coefficients
    G = buildG_odd_even(p,c);
    
    % update image
    fprintf('Updating img...\n');
 [ T2_map, PD, img,param] = imgupdate_odd_even(p,G,data,param);
 
    % calculate cost and check exit conditions
    cost(end+1) = cost_eval_odd_even(data,img,p,G);
    fprintf('Current cost: %d ... \n', cost(end));
    if length(cost) == p.maxiters+1
        fprintf('Exiting; max number of iterations reached.\n');
        keepgoing = 0;
    end
    if (cost(end-1)-cost(end) < cost(end)/100)
        fprintf('Exiting; cost is no longer decreasing significantly.\n');
        keepgoing = 0;
    end
    
    % save progress and increment iter counter
    csv(:,:,end+1) = c;
    imgsv(:,:,:,end+1) = img;
    
    disp('====================================================');
    
end

p.runtime = toc(tti); %in s


