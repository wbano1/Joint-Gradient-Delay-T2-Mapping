function [img_TrACR,c_TrACR,cost,imgsv,csv,p,param] = TrACR_sequential_odd_even(data_full,p,param)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
ksp=p.knom;
TEs=5:5:40;

data_even=data_full(:,:,:,2:2:end);
p.knom=ksp(:,:,2:2:end);
p.wi=param.w(:,:,2:2:end);
param.TE=TEs(2:2:end);
p.echo=numel(param.TE);
fprintf('Running Even Echoes')

[img_TrACR_even,c_TrACR_even,cost,imgsv,csv,p,param] = TrACR_ed_Sequential(data_even,p,param);
fprintf('Running Odd Echoes')

data_odd=data_full(:,:,:,1:2:end);
p.knom=ksp(:,:,1:2:end);
p.wi=param.w(:,:,1:2:end);
param.TE=TEs(1:2:end);
p.echo=numel(param.TE);

[img_TrACR_odd,c_TrACR_odd,cost,imgsv,csv,p,param] = TrACR_ed_Sequential(data_odd,p,param);
img_TrACR=zeros(p.dim,p.dim,numel(TEs));
c_TrACR=zeros(size(p.eb,2),numel(TEs));
c_TrACR(:,2:2:end)= repmat(c_TrACR_even,[1 numel(param.TE)]);
c_TrACR(:,1:2:end)= repmat(c_TrACR_odd,[1 numel(param.TE)]);

img_TrACR(:,:,2:2:end)=img_TrACR_even;
img_TrACR(:,:,1:2:end)=img_TrACR_odd;

end

