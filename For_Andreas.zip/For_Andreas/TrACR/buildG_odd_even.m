function G = buildG_odd_even(p,c)
% reconstruct estimated total k-space trajectory


for kk=1:p.echo %WB 01/08
    % reconstruct estimated total k-space trajectory
    k_temp = p.knom(:,:,kk);
    k_temp= k_temp + reshape(p.eb*c(:,kk),size(p.knom(:,:,1)));
    updatedk(:,:,kk)= reshape(complex(k_temp(:,1),k_temp(:,2)),[p.npts,p.nproj]);
end 
   updatedk = updatedk.*p.fov./p.dim;
%   2*pi*updatedk./(p.dim./p.fov./2)./2;
%    updatedk = 2*pi*updatedk./(p.npts./p.fov./4)./2;
 

% normalize it
if p.useGPU % AW_EDITSs
    % build the NUFFT (Greengard separable Gaussian kernel)
%     p.wi=reshape(p.wi,size(k,1),1);
    G = MCNUFFT_gpuNUFFT_new(double(updatedk),double(p.wi),p.SENSEmap);
    %gpuNUFFT(double(k'),ones(size(p.wi)), 1.5, 5, 16,[p.dim p.dim],[]);
else
%     k=complex(k(:,1),k(:,2));
%     k=reshape(k,[p.npts,p.nproj]);
%     %p.wi=reshape(p.wi,size(k,1),1);
     G = MCNUFFT(double(updatedk),double(p.wi),p.SENSEmap);
%     %G = NUFFT(k, p.wi,1, [0,0], [p.dim p.dim], 2);
%     G = NUFFT(k, ones(size(p.wi)),1, [0,0], [p.dim p.dim], 2);
end