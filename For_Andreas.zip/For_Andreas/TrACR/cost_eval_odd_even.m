%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Calculate cost of data term
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function cost = cost_eval_odd_even(data,img,p,G)


% data fidelity term (same for SPIRiT and SENSE)
cost = 0;
 res = data - (G*img); %WB 1/08

if p.useparfor
    parfor ii = 1:p.ncoils
       
        res = data - col(G*img);
        cost = cost + 1/2*real(res'*(col(p.wi).*res));
    end
else
%WB 1/08
    for ii = 1:p.ncoils
        for jj=1:p.echo
        cost = cost + 1/2*real(col(res(:,:,ii,jj))'*col(res(:,:,ii,jj)));
        end
    end
end

% add on the SPIRiT regularization
if strcmp(p.reconalg,'SPIRiT')
    cost = cost + p.lam*sum(col(abs(p.SPIRiTop*reshape(img,[p.dim p.dim p.ncoils]))).^2);
end


