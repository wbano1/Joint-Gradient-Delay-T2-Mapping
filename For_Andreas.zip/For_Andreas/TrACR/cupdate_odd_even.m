%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% k-space error coefficient update function
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [c,nn] = cupdate_odd_even(p,data,img,c)

%odd first
g = [];

thresh = 1e-6; % stopping threshold (in k-space traj units, eg cm^-1)

for nn = 1:p.niterk
    
    % calculate gradient
    gold = g;
    g = kgradcalc_odd(p,data,img,c);
    
    % calculate a search direction
    if nn == 1
        dir = -g;
    else
        gamma = real(g(:)'*(g(:)-gold(:)))/real(gold(:)'*gold(:));
        dir = -g + gamma*dir;
    end
    
    % calculate a step size that reduces cost
    t = kstepcalc_odd(p,data,img,c,g,dir,thresh);
    c(:,1:2:end) = c(:,1:2:end)+ t*dir; % take step
    
    % exit if step is insignificant
    if t*max(abs(p.eb*dir)) < thresh ; break; end
end  
    g = [];

thresh = 1e-6; % stopping threshold (in k-space traj units, eg cm^-1)

for nn = 1:p.niterk
    
    % calculate gradient
    gold = g;
    g = kgradcalc_even(p,data,img,c);
    
    % calculate a search direction
    if nn == 1
        dir = -g;
    else
        gamma = real(g(:)'*(g(:)-gold(:)))/real(gold(:)'*gold(:));
        dir = -g + gamma*dir;
    end
    
    % calculate a step size that reduces cost
    t = kstepcalc_even(p,data,img,c,g,dir,thresh);
    c(:,2:2:end) = c(:,2:2:end) + t*dir; % take step
    
    % exit if step is insignificant
    if t*max(abs(p.eb*dir)) < thresh ; break; end
end
end