function [vargout] = display_TrACR_result(p,c,imgsv,img,cost)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here

% for kk=1:p.echo %WB 01/08
%     % reconstruct estimated total k-space trajectory
%     k_temp = p.knom(:,:,kk);
%     k_temp= k_temp + reshape(p.eb*c,size(p.knom(:,:,1)));
%     updatedk(:,:,kk)= reshape(complex(k_temp(:,1),k_temp(:,2)),[p.npts,p.nproj]);
% end
%   updatedk = updatedk.*p.fov./p.dim;
% updatedk = 2*pi*updatedk./(p.npts./p.fov./4)./2;
 fprintf(['TrACR finished with: %4.0f iterations. \n ', ...
     'Total compute time: %3.0f minutes %3.0f seconds\n'], ...
     size(cost,2)-1,p.runtime/60, rem(p.runtime,60));

%display results-----------------------------------------------------------
img_initial = imgsv(:,:,1,1);
img_final = img(:,:,1);
figure; subplot(2,2,1); imagesc(abs(img_initial),[0 max([abs(img_initial(:)); abs(img_final(:))])]);
colormap gray; title('initial sum-of-squares image'); axis off; axis image;
subplot(2,2,2); imagesc(abs(img_final),[0 max([abs(img_initial(:)); abs(img_final(:))])]);
colormap gray; title('final sum-of-squares image'); axis off; axis image;
subplot(2,2,3); imagesc(abs(img_final-img_initial));
colormap gray; title('difference'); axis off; axis image;
subplot(2,2,4); semilogy(cost); xlabel('iteration #'); ylabel('data cost term');
title('cost');
end

