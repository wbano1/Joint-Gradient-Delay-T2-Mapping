%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% image update function
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [T2_map, PD, img,param] = imgupdate_odd_even(p,G,yALS,param)

% k_temp= p.knom + reshape(p.eb*c,size(p.knom));
% updatedk= reshape(complex(k_temp(:,1),k_temp(:,2)),[p.npts,p.nproj]); %Reshape, then repeat for 8 echoes to work with MCNUFFT operator
% param.k=repmat(updatedk,[1 1 8]);
% param.k(:,:,2:2:end)=param.k(:,:,2:2:end)*-1; %Change sign of even echoes
% param.E=MCNUFFT_gpuNUFFT(double(param.k), double(param.w),csm); %Updating param.E

if strcmp(p.reconalg,'SENSE')
    %reconstruct images with current k-space using SENSE
    if p.useInitialGuess
%     for tt=1:p.echo
%         for ch=1:p.ncoils
%             b = yALS(:,:,ch,tt).*sqrt(p.wi(:,:,tt));
%             res(:,:,ch,tt) = b;
%         end
%     end
        imginit = G'*yALS;
    else
        imginit = zeros([p.dim p.dim p.echo]);
    end

     [T2_map, PD, img,param] = recon_SENS_Will_GPU(yALS,G,imginit,p.SENSEmap,param,p);
%     img = recon_SENS(yALS,imginit,p.niteri,p.wi,G,p.SENSEmap);

    % replicate body coil image to all Rx coils
%     for ii=1:p.ncoils
%         img_up(:,:,ii,:) =  p.SENSEmap.*...
%                 repmat(img(:,:,ii),[1 1 p.ncoils]);
else
    %reconstruct images with current k-space using SPIRiT
    imginit = zeros([p.dim p.dim p.ncoils]);
    img = recon_SPIR(data,imginit,G,p.SPIRiTop,p.niteri,p.lam,p.wi);
    
end
% collapse the image's spatial dims
% img = permute(img,[3 1 2]);img = img(:,:).';