%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% calculate k-space basis derivatives
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function g = kgradcalc_even(p,data,img,c)

% p contains base k-space and error basis functions
% data contains k-space data
% img contains most recent image guess
% c contains most recent error coefficients guess
img=double(img);
% setup NUFFT with the newest coefficients
G = buildG_odd_even(p,c);

Nc = size(data,4);

% calculate gradient
g = 0;
%WB 1/08

res = double(data) - (G*(img));
p.x=repmat(reshape(p.x,[p.dim p.dim]),[1 1 Nc]);
p.y=repmat(reshape(p.y,[p.dim p.dim]),[1 1 Nc]);
temp = conj(1i*2*pi*(G*(img.*p.x))).*(res);
temp2=conj(1i*2*pi*(G*(img.*p.y))).*(res);
if p.useparfor
    parfor ii = 1:Nc % loop over Rx coils
        
%         res = data(:,ii) - col(G*img(:,ii)); %calc residual
        g = g + p.eb'*double([real(conj(1i*2*pi*col(temp(:,:,ii,jj)))); ...
             real(conj(1i*2*pi*col(temp2(:,:,ii,jj))))]);
        
    end
else
    %WB 1/08

    for ii = 1:Nc % loop over Rx coils
        for jj=2:2:p.echo
%         res = data(:,ii) - col(G*img(:,ii)); %calc residual
        g = g + p.eb'*double([real(col(temp(:,:,ii,jj))); ...
             real(col(temp2(:,:,ii,jj)))]);
        end
    end
end
