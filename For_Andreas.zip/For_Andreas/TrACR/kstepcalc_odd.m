%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% find a step size
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function t = kstepcalc_odd(p,data,img,c,g,dir,thresh)

% setup NUFFT with the newest coefficients
G = buildG_odd_even(p,c);

% calculate starting cost
cost = cost_eval_odd_even(data,img,p,G);

% set max step size so that the maximum the traj can change in 1 update is less than
% 1/fov
tmax = min([1,1/max(p.fov)/max(abs(p.eb*dir))]);

if ~p.bls % do our own uniform backtracking line search
    
    keepgoing = 1;
    t = 0; % in case we never enter the loop
    nsteps = 10; % # of steps from 0 to max step size to consider
    
    while keepgoing && tmax*max(abs(p.eb*dir)) > thresh
        
        G = buildG(p,c + dir*tmax/nsteps);
        costt = cost_eval(data,img,p,G); %get cost w/current min step;
        
        % check whether alphamax/nsteps yields a lower cost than we currently have
        if costt < cost
            
            % if it does, go ahead and evaluate cost over current interval
            costt = [];
            if p.useparfor
                parfor ii = 1:nsteps
                    % set up NUFFT and evaluate cost with this step size
                    G = buildG_odd_even(p,c + dir*ii*tmax/nsteps);
                    costt(ii) = cost_eval_odd_even(data,img,p,G);
                end
            else
                for ii = 1:nsteps
                    % set up NUFFT and evaluate cost with this step size
                    G = buildG_odd_even(p,c + dir*ii*tmax/nsteps);
                    costt(ii) = cost_eval_odd_even(data,img,p,G);
                end
            end
            
            % find lowest cost and exit
            [~,mini] = min(costt);
            t = tmax/nsteps*mini;
            keepgoing = 0;
            
        else
            
            % if it doesn't, decrease alphamax and look over smaller interval
            tmax = tmax/nsteps;
            
        end
    end
    
else % use boyd's backtracking line search, which usually requires fewer cost evaluations
    
    % line search to get step
    costt = cost;
    a = 0.5; b = 0.5; t = tmax/b;
    while (costt > cost + a*t*real(g(:)'*dir)) && t*max(abs(p.eb*dir)) > thresh
        
        % reduce t
        t = b*t;
        
        % get test point
        ct=c;
        ct(:,1:2:end) =  ct(:,1:2:end) +  t*dir;
        
        % set up NUFFT and evaluate cost with this step size
        G = buildG_odd_even(p,ct);
        costt = cost_eval_odd_even(data,img,p,G);
        
    end
    
    if t == tmax/b || t*max(abs(p.eb*dir)) < thresh % loop was never entered or step was too small; return zero step
        t = 0;
    end
    
end