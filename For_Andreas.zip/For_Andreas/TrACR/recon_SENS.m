function [img,flag,relres,iter,resvec,lsvec] = recon_SENS(data,imginit,niteri,wi,G,SENSEmap,tol)
% reconstruct an image from non-Cartesian acquisitions, using SENSE

%data       =   initial k-space data (must be a double!)
%imginit    =   initial image
%niteri     =   number of lsqr iterations
%wi         =   density weights
%G          =   NUFFT object (set with Gnufft)
%SENSEmap   =   map of coil sensitivities (must be a double!)

% SENSEmap = SENSEmap(:);
 N = numel(imginit);     %number of image points
imSize = size(imginit); %image size
dataSize = size(data);  %k-space data size
 b = data(:).*repmat(sqrt(wi(:)),[length(data(:))/length(wi(:)) 1]);
%  wi=sqrt(wi(:));
if ~exist('tol','var')
    tol=1e-3;
end
%perform least-squares recon
[img,flag,relres,iter,resvec,lsvec] = lsqr(@(x,transp_flag)ismrm_encoding_noncartesian_SENSE(x,wi,G,SENSEmap,transp_flag), b , tol, niteri,[],[],imginit(:));


img = reshape(img,imSize);
function y =  ismrm_encoding_noncartesian_SENSE(x,wi,E,csm,transp_flag)
Nx=size(wi,1);
 Ny=size(wi,2);
 Nc=size(csm,3);
 Ne=size(wi,3);
if (strcmp(transp_flag,'transp'))
 
 x=reshape(x,[Nx,Ny,Nc,Ne]);
 for tt=1:Ne
        for ch=1:Nc
            b = x(:,:,ch,tt).*sqrt(wi(:,:,tt));
            res(:,:,ch,tt) = b;
        end
 end
   y=E'*(res);
%     y = sum(conj(csm) .* y,3);
    y = y(:);
elseif (strcmp(transp_flag, 'notransp'))
 y1 = reshape(x,size(csm,1),size(csm,2),Ne);
%     outp = ft(outp, [1,2]);
    y1=(E*y1);
  for tt=1:Ne
        for ch=1:Nc
            b = y1(:,:,ch,tt).*sqrt(wi(:,:,tt));
            res(:,:,ch,tt) = b;
        end
 end
%     y1=y1.*repmat(sqrt(wi),[1 1 1 size(y1,4)]);
    y=res(:);
else
    error('Transpose flag not appropriately defined');
end 
end

% function [y, transp_flag] = afun(x,wi,dataSize,imSize,G,csm,transp_flag)
% 
% if strcmp(transp_flag,'transp')
%     
%    x=reshape(x,dataSize);
%    for tt=1:dataSize(4)
%     x(:,:,:,tt)= x(:,:,:,tt).*sqrt(wi(:,:,tt));
%    end
%    y=G'*(x);
% %    y = sum(conj(csm) .* y,3);
%     y = y(:);
% %     %reshape to orig data size
% %     x1 = reshape(x(1:prod(dataSize)),dataSize);
% %     numcoils = dataSize(end);
% %     y = zeros([imSize, numcoils]);
% %     parfor ii = 1:numcoils
% %         %type I NUFFT
% %         y(:,:,ii) = reshape(G'*(wi.*x1(:,ii)),imSize);
% %     end
% %     y = y(:);
% %     y = conj(SENSEmap).*y;
% %     y = reshape(y,[prod(imSize),dataSize(end)]);
% %     y = sum(y,2);
% elseif (strcmp(transp_flag, 'notransp'))
%  y1 = reshape(x,imSize);
% %     outp = ft(outp, [1,2]);
%     y1=G*(y1);
% for tt=1:dataSize(4)
%     res(:,:,:,tt)= y1(:,:,:,tt).*sqrt(wi(:,:,tt));
% end
%     y=res(:);
% else
%     error('Transpose flag not appropriately defined');
% 
% %     xt=SENSEmap.*repmat(x,[dataSize(end) 1]);
% %     xt=reshape(xt,[imSize dataSize(end)]);
% %     numcoils=dataSize(end);
% %     y1=zeros(dataSize);
% %     parfor ii = 1:numcoils
% %         xtall = xt(:,:,ii);
% %         %type II NUFFT
% %         y1(:,ii)=wi.*col(G*xtall(:));
% %     end
% %     y = y1(:);
% 
 end

% function out = col(in)
% 
% out = in(:);
% end