function [T2_map, PD, img, param] = recon_SENS_Will_GPU(yALS,G,z,csm,param,p)
% reconstruct an image from non-Cartesian acquisitions, using SENSE, with
% ALSTV additions to update MCNUFFT

%data       =   initial k-space data (must be a double!)
%imginit    =   initial image
%niteri     =   number of lsqr iterations
%wi         =   density weights
%G          =   NUFFT object (set with Gnufft)
%SENSEmap   =   map of coil sensitivities (must be a double!)

% lambda =0.24; %Regularization parameters
% param.E=MCNUFFT_gpuNUFFT(double(param.k), double(p.wi),csm); %Updating operator with new k-space
 lambda=param.lambda;
%  z=G'*((yALS).*sqrt(param.w));
E = @(xALS,tr)ismrm_encoding_noncartesian_SENSE(xALS,ones(size(p.wi)),G,csm,tr);
B = @( xALS ,~) (E( E( xALS ,'notransp'),'transp') )+ lambda * xALS(:) ;
% b = yALS(:).*repmat(sqrt(p.wi(:)),[length(yALS(:))/length(p.wi(:)) 1]);
% [img,flag,relres,iter,resvec,lsvec] = lsqr(@(x,transp_flag)ismrm_encoding_noncartesian_SENSE(x,ones(size(p.wi)),G,csm,transp_flag), b , 10-06, [],[],[],z(:));

%%
    %Step 1 of Alternating minimization (ALSTV)
u = E(yALS,'transp')+lambda.*z(:);
% u = yALS(:).*repmat(sqrt(p.wi(:)),[length(yALS(:))/length(p.wi(:)) 1]);
 xALS= lsqr(B,u,1e-4,100);
 xALS = reshape(xALS,size(z));
%     %Step 2
[T2_map, PD, img,r2]=log_lin(xALS ,param.TE);
param.r2=r2;
obj = 1/2* norm( yALS(:)-E(xALS,'notransp'))^2 +lambda/2 *norm(xALS(:) -img(:))^2; %Objective indicates whether image is improving
fprintf('Obj=%e\n',obj);
%%
% SENSEmap = SENSEmap(:);
% N = numel(imginit);     %number of image points
% imSize = size(imginit); %image size
% dataSize = size(data);  %k-space data size
% 
% b = data(:).*repmat(sqrt(wi(:)),[length(data(:))/length(wi(:)) 1]);
% wi=sqrt(wi(:));
% if ~exist('tol','var')
%     tol=1e-6;
% end
% %perform least-squares recon
% [img,flag,relres,iter,resvec,lsvec] = lsqr(@(x,transp_flag)afun(x,wi,dataSize,imSize,G,SENSEmap,transp_flag), b, tol, niteri,speye(N,N),speye(N,N), imginit(:));

% img = reshape(img,imSize);




% function [y, transp_flag] = afun(x,wi,dataSize,imSize,G,SENSEmap,transp_flag)
% if strcmp(transp_flag,'transp')
% 
%     %reshape to orig data size
%     x1 = reshape(x(1:prod(dataSize)),dataSize);
%     numcoils = dataSize(end);
%     y = zeros([imSize, numcoils]);
%     parfor ii = 1:numcoils
%         %type I NUFFT
%         y(:,:,ii) = reshape(G'*(wi.*x1(:,ii)),imSize);
% 
%     end
%     y = y(:);
%     y = conj(SENSEmap).*y;
%     y = reshape(y,[prod(imSize),dataSize(end)]);
%     y = sum(y,2);
% 
% else
% 
%     xt=SENSEmap.*repmat(x,[dataSize(end) 1]);
%     xt=reshape(xt,[imSize dataSize(end)]);
%     numcoils=dataSize(end);
%     y1=zeros(dataSize);
%     parfor ii = 1:numcoils
%         xtall = xt(:,:,ii);
%         %type II NUFFT
%         y1(:,ii)=wi.*col(G*xtall(:));
%     end
%     y = y1(:);
% 
% end
% 
% function out = col(in)
% 
% out = in(:);
