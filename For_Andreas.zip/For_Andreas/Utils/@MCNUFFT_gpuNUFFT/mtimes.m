function ress = mtimes(a,bb)

if a.adjoint,
    % Multicoil non-Cartesian k-space to Cartesian image domain
    % nufft for each coil and time point
    
    bb = reshape(bb, size(bb, 1) * size(bb, 2), size(bb, 3), size(bb, 4));
    
    for tt=1:size(bb,3),

        %res(:,:,ch) = reshape((a.st{tt}' * bb(:, :, tt))/sqrt(prod(a.imSize2)),a.imSize(1),a.imSize(2));

        %ress(:,:,:, tt)=sum(res.*conj(a.b1),3)./sum(abs((squeeze(a.b1))).^2,3);
        
        ress(:,:,tt) = a.st{tt}' * bb(:, :, tt);
    end
%     ress=ress.*size(a.w,1)*pi/2/size(a.w,2);
%     ress = ress;
else
    % Cartesian image to multicoil non-Cartesian k-space
    for tt=1:size(bb,3),
        %for ch=1:size(a.b1,3),
        %    res=bb(:,:,tt).*a.b1(:,:,ch); 
        ress(:,:,tt) = (a.st{tt} * bb(:,:,tt));%/sqrt(prod(a.imSize2)),a.dataSize(1),a.dataSize(2));
        %end
    end
    ress = reshape(ress, size(a.w, 1), size(a.w, 2), size(ress, 2), size(ress, 3));
    ress = ress;
end


