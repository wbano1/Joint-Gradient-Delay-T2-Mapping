function res = times(a,b)

if isa(a,'Wavelet') == 0
    error('In  A.*B only A can be Wavelet operator');
end
for t=1:size(b,3)
if a.adjoint
    res(:,:,t) = IWT2_PO(real(b(:,:,t)),a.wavScale,a.qmf) + i*IWT2_PO(imag(b(:,:,t)),a.wavScale,a.qmf);
else
    res = FWT2_PO(real(b(:,:,t)),a.wavScale,a.qmf) + i* FWT2_PO(imag(b(:,:,t)),a.wavScale,a.qmf);
end
end


