function [ CoilSense ] = DirectCoilSense(data, param)

[dimY, dimX, dimCoils ] = size(data);
reflines=[dimY  dimX];

% data = squeeze(sum(data(:,:,1:end,:),3));
% apply Hanning-Filter
filterY = zeros(dimY,1);
filterX = zeros(dimX,1);
filterY(dimY/2-reflines(1)/2+1:dimY/2+reflines(1)/2) = squeeze(hamming(reflines(1)));
filterX(dimX/2-reflines(2)/2+1:dimX/2+reflines(2)/2) = squeeze(hamming(reflines(2)));
filter = filterY*filterX';
data = data(:,:,:) .* repmat(filter,[1 1 size(data,3)]);

% % inverse Fourier Transform
% k=squeeze(sum(param.k(:,:,1:end,:),3));
% % density compensation
% w = radial_dcf_2d(k); % somewhere we should include a Hann or Hamming filter to suppress Gibbs-ringing. Maybe here?
% w = w .* hamming(param.nkx, 'periodic');


% need NUFFT for coil sensitivities (set sensitivites to 1):
param.E=MCNUFFT(double(param.k), double(param.w), ones(param.nx));
    
% reconstruct first echo separately for each coil (otherwise MCNUFFT operator tries to
% combine the images ...)
CoilSense = zeros(param.nx, param.ny, param.channel); % hybrid x-y-kz space

  for coil = 1:param.channel
 
    % this pre-density compensation is necessary because of the way the weights
    % are implemented in the MCNUFFT operator (again adjoint being the reason)
  CoilSense(:, :,coil) = param.E'* (squeeze(double(data(:, :, coil))) .* sqrt(param.w));
    
  end

% normalize
sumSqrC = sqrt(sum(CoilSense .* conj(CoilSense),3));
CoilSense   = CoilSense ./ repmat(sumSqrC,[1,1,dimCoils]);
% CoilSense=repmat(CoilSense,[1 1 1 dimCoils]);
end