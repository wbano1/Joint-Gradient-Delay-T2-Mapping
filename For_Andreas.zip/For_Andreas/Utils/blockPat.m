function [P, sampledInds] = blockPat(data, varargin)
% blockPat:
%
% Simulates block undersampling on given multi-echo data array
%
% Usage:
%   [P, sampledInds] = blockPat(data, varargin)
%
%       data:  3D or 4D array with 
%              dimensions = [phaseDirection, readDirection, echoes, coils]
%
%       varargin:
%               'af'        = acceleration factor 
%               'startat'   = 'first' or 'second' echo (default)
%
%
%   Written by: Tilman Sumpf (tsumpf@gwdg.de)
%
%
%   Version 1.0, 12/06/2011





si = size(data);
if length(si) >4 || length(si) < 3
    error('blockPat:argChk','input array must have at least 3 dimension ([phase, read, echoes])');
end
[dimPE, dimRE, NE, NC] = size(data); % [phaseDirection, readDirection, echoes, coils]

if nargin == 2
    % if we have only 2 arguments,
    % interpret second argument as Acceleration factor
    AF = varargin{1};
else
    AF = round(NE/2);
end


%---------------------------------
% evaluate varargin
%---------------------------------
startAt     = 'second';
if nargin > 2
    for i = 1 : floor(length(varargin)/2)
        option       = varargin{i*2-1};
        option_value = varargin{i*2};
        
        switch lower(option)
            case 'af'   % Acceleration factor
                AF = option_value;                
            
            case 'startat'
                startAt = option_value;  % put center k-space sampleds at first or second echo?
                % 'first', 'second' (default)
                
            otherwise
                error('blockPat:argChk','unknown option [%s]!\n',option);
        end
    end
end
if AF > NE
    error('blockPat:argChk','Acceleration factor cannot be greater than the number of echoes');
end
if mod(dimPE, AF)
    warning('blockPat:argChk','Modulus(dimPE, accelerationFactor) should be zero');
end





%---------------------------------
% init variables and pattern start position
%---------------------------------
sampledInds = cell([NE,1]);  % indices of sampled k-space lines for every echo
P = zeros([dimPE, dimRE, NE, NC]);

blockSize = ceil(dimPE / AF);

switch startAt % put center k-space sampleds at first or second echo
    case 'first'
        start = ceil(dimPE/2) + 1 - ceil(blockSize / 2);
    case 'second'
        start = ceil(dimPE/2) + 1 - ceil(3*blockSize / 2);
        if start < 1
            start = start + dimPE;
        end
end





%---------------------------------
% create pattern
%---------------------------------
for n = 1 : NE
    stop = start + blockSize - 1;
    if stop > dimPE
        % wrap around case
        stop = stop - dimPE;
        topRange = 1 : stop ;
        
        botRange = start : dimPE;
        
        range = [topRange, botRange];
        
        % next start
        start = stop + 1;
    else
        % normal case
        range = start : stop;
        
        % next start
        if stop >= dimPE
            start = 1;
        else
            start = start + floor(blockSize);
        end
        
    end
    P(range,:,n,:) =  data(range,:,n,:);
    sampledInds{n} = range;
end


end