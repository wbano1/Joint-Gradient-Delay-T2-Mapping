function [Image,kdata_u,param,sens_map,T2_phantom] = complex_density_brain_phantom(param,varargin)
% This function builds an MRF phantom using the Brainweb anatomical phantom
% along with selected T1, T2 and pd values based on existing tables 
% The anatomical model was described in:
% Design and Construction of a Realistic Digital Brain Phantom,
% DL Collins, AP Zijdenbos, V Kollokian, JG Sled, NJ Kabani, CJ Holmes and
% AC Evans. 
% IEEE Transactions on Medical Imaging, vol.17, No.3, p.463--468, June
% 1998.  
% 
% The function then adds a quadratic phase term that is zero in the centre of the image and pi/4 at the corners
% to make the density complex valued
%
% The function takes in RFpulses and TR sequences and returns the phantom
% and density image. 
% 
% Written by Mike Davies 23-05-14

% load in MNI segmented brain phantom
% MNI segmented brain phantom is segmented into:
%(0=Background, 1=CSF, 2=Grey Matter, 3=White Matter, 4=Fat, 5=Muscle/Skin, 6=Skin, 7=Skull, 8=Glial Matter, 9=Connective)

% Modification by Wajiha 10-07-2017

%Create b1 and b2 to generate complex phantom data
%Use a sensitivity Map generation function for sensitivity maps and created
%images according to that
% Convert Image to kspace and undersample it according to the Sampling
% Pattern
%Modification by Wajiha 22-11-2019
%Numerical phantom for Radial T2* Mapping
%Including three different undersampling pattern

%Input: 
%param: 
        % param.nx= x-res of the image
        %param.ny= y-res of the image
        %param.echo= No. of echoes
        %param.channel= No. of channels
        % param.TE= TEs
        %param.nkx= x-res of kspace
        %param.nky= y-res of kspace
        %param.undersampleSpokesTo= No. of spokes to use 
%         param.pair=2; % In alternate echoe case e.g For 2-> echo pairs will be 1,5 2,6 3,7 4,8 etc 
% param.snr=0; % Standard deviation of noise
%Varargmin
            % 'Uniform': Same angles of spokes are removed in each echo
            % 'Alternate' : depending on the Number of pair the angles of
            % spokes change e.g if param.pair=4 1,3,5,7 will have same
            % undersampling 
            %'Rotating': The angle of the spokes rotate in each echoe e.g 2
            %degrees
%Output: 
            % Image: Ground truth Image
            % kdata_u: Undersampled kspace
            % param: parameters for reconstruction
            % sens_map: Coil sensitivities 
            % T2_Phantom : Ground T2* 

%===============================================================================
 [imaVol,scaninfo] = loadminc('phantom_1.0mm_normal_crisp.mnc'); % volume is  217   181   181

 %... and select a slice
 
 nx=param.nx;
 ny=param.ny;
 ncha=param.channel;
 neco=param.echo;
 nkx=param.nkx;
 nky=param.nky;
 TE=param.TE;
 Slice = zeros(nx,ny);
 Slice(21:237,37:217) = imaVol(:,:,80);
 Slice = Slice.*(Slice<7);  % remove skull Glial matter and connective
 
% Tissue table chosen to match chemicals from Basics of MRI webbook:
% NOTE the pd are chosen to be particularly challenging.

% 8 is empty!
% From Basics of MRI (Web book)
% Tissue        T1 (s)      T2 (ms)     r*            phantom index
% Background    -           -           0                   0
% CSF           0.8 - 20    110 - 2000  70-230              1
% Gray          1.09 - 2.15 61 - 109    85 - 125            2
% White         0.76 - 1.08 61-100      70-90               3    
% Adipose       0.2 - 0.75  53 - 94     50 - 100            4  
% Muscle        0.95 - 1.82 20 - 67     45 - 90             5/6
 
% T1 = [0,5012,1545,811,530,1425,1425];
 T2 = [0, 2000,65,77,77,41,41];
 pd = [0, 100,100,80,80,80,80];
%  df = [0, 0, 0, 0, 0, 0, 0];
 
 L = length(TE);
 phantom = zeros(nx,ny,L);
density = zeros(nx,ny);
b1 = zeros(nx,ny);
T2_phantom = zeros(nx,ny);
b2= zeros(nx,ny);
 
 
 % Generate phase error
 
 xx = ones(nx,1)*linspace(-1,1,ny);
 yy=xx';
 phase_angle = (pi/4).*(xx.^2+yy.^2)./2;
 density_phase = exp(sqrt(-1).*phase_angle);
 

 % calculate parameter maps for pahantom
  
 for i = 0:6
     
     density = density+(Slice==i).*pd(i+1);  
%      T1_phantom = T1_phantom+(Slice==i).*T1(i+1);          
     T2_phantom = T2_phantom+(Slice==i).*T2(i+1);
%      df_phantom = df_phantom+(Slice==i).*df(i+1);
     
 end
 
 % modulate density with complex phase
 
  density = density.*density_phase;
  PD=abs(density);
  b1=angle(density);
%   b2= (b1./2*pi)*randn;
     b2=zeros(size(b1));
 % Calculate the Response
 Response = @(x1,x2,x3,x4,te)...
    x1.* exp(-te./x2 +1i*(x3-x4*te) );



     for ii=1:numel(TE)
       phantom(:,:,ii) = Response(PD,T2_phantom,b1,b2,TE(ii));
     end

     
 %calculate Sensitivity Map
 
csm=sensitivity_map([nx,ny],ncha);
csm=permute(repmat(csm,[1 1 1 neco]),[1 2 4 3]);
Image=phantom.*csm;

 sens_map=zeros(size(Image));

        for t = 1 : length(TE)
                [~,sens_map(:,:,t,:)]=adapt_array_2d(squeeze(Image(:,:,t,:)));
        end

  sens_map(isnan(sens_map))=0;
  %% Add measurement noise - snr in dB 20*log10(Y/(Noise)) 
% Image = Image + randn(size(Image))*std(Image(:))*10^(-param.snr/20);
Image=permute(Image,[1,2,4,3]);
G_angle = pi * 2 / (1 + sqrt(5)); % is it simply golden angle or are we missing something?

%Generate k-space Fully Sampled
    spokesOffset=0;
    spokes=nky;
    phi = [pi/2+spokesOffset*G_angle:G_angle:G_angle*spokes+spokesOffset*G_angle];
    k = (-nkx/2:nkx/2-1).' / nx / 2 .* exp(1i * phi);
     phi = [pi/2+spokesOffset*G_angle:G_angle:G_angle*spokes+spokesOffset*G_angle];
% %         k = (-Nkx/2:Nkx/2-1).' / Nx / 2 .* exp(1i * phi); 
         rho = linspace(0,nkx-1,nkx)' - (nkx-1)/2; %AW: this implicitly assumes even Nkx (as did my code).
         rho = rho/nx/2;
          k= double(rho*exp(-1j*phi));
% if param.graddelay
% kx = real(k);
% ky = imag(k);
% kx_true = zeros(size(k));
% ky_true = zeros(size(k));
% % delay in x = 1
% % kx_true(2:end,:) = kx(1:end-1,:); 
% % kx_true(1,:) = kx(1,:); 
% % % 2*kx(1,:)-kx(2,:); 
% % 
% % % delay in x = -2
% % % kx_true(1:end-2,:) = kx(3:end,:); 
% % % kx_true(end-1:end,:) = repmat(kx(end,:),[2 1]);
% % 
% % % delay in y = 2
% % ky_true(3:end,:) = ky(1:end-2,:); 
% % ky_true(1:2,:) = repmat(ky(1,:),[2 1]);
% % 
% % delay in y = -1
% % ky_true(1:end-1,:) = ky(2:end,:); 
% % ky_true(end,:) =ky(end,:);
% % % % 2*ky(end,:)-ky(end-1,:); 
% % ky_true(1:end-1,:) = ky(2:end,:); 
% % ky_true(end,:) = 2*ky(end,:)-ky(end-1,:); 
% 
% k = complex(kx_true,ky_true);
% 
% % zeros(size(k,1),size(k,2));
% % k_true(1,:,:) = kx_true(:,:);
% % k_true(2,:,:) = ky_true(:,:);
% end

% data = bart('bart nufft',k_true*N(1),reshape(channel_im,[N 1 Nc]));
% data = reshape(data,[size(k) Nc]);
scale=0;

%% add noise
% noise = randn(size(data)) + 1j*randn(size(data));
% data = data + 5000* noise*scale;
    %k = (-nkx/2:nkx/2-1).' / nx / 2 .* exp(1i * (angle * (0:nky-1) + angle_offset)); % 2 is for readout oversampling ...
    
    
    kdata = zeros(nkx, nky, neco, ncha); % hybrid x-y-kz space
    % density compensation
    w = radial_dcf_2d(k); % somewhere we should include a Hann or Hamming filter to suppress Gibbs-ringing. Maybe here?
    w = w .* hamming(nkx, 'periodic');

% need NUFFT for coil sensitivities (set sensitivites to 1):
param.E=MCNUFFT(double(k), double(w), ones(nx));
for echo=1:neco
  for coil = 1:ncha  
 
    % this pre-density compensation is necessary because of the way the weights
    % are implemented in the MCNUFFT operator (again adjoint being the reason)
    kdata(:, :, echo,coil) = param.E* squeeze(double(Image(:, :, echo, coil)));
    
  end
end
% Add measurement noise 
% kdata = kdata+randn(size(kdata))*param.snr + i*randn(size(kdata))*param.snr;
%  noise = randn(size(kdata)) + 1j*randn(size(kdata));
%  kdata = kdata + 5000* noise*scale;
%% Undersample the kspace

option=varargin{1};
  param.undersampleSpokesTo= floor(nky/param.pair);

  kdata_u= complex(zeros(nkx,param.undersampleSpokesTo, neco, ncha, 'single'));
  k_u= zeros(nkx,param.undersampleSpokesTo,ncha);
  w_u=zeros(size(k_u));
   
 switch option
     
        case 'Uniform'
        spokesOffset=nky-param.undersampleSpokesTo;
        spokes=double(param.undersampleSpokesTo);
        phi = [pi/2+spokesOffset*G_angle:G_angle:G_angle*spokes+spokesOffset*G_angle];
        k = (-nkx/2:nkx/2-1).' / nx / 2 .* exp(1i * phi); % 2 is for readout oversampling ...
        fprintf('Undersampling spokes to = %d\n', spokes); 
        kdata_u=kdata(:,1+spokesOffset:spokes+spokesOffset,:,:); 
        w = radial_dcf_2d(k); % somewhere we should include a Hann or Hamming filter to suppress Gibbs-ringing. Maybe here?
        w = w .* hamming(nkx, 'periodic');
        k_u=repmat(k,[1 1 8]);
        w_u=repmat(w,[1 1 8]);
    
    case 'Alternate'   
spokesOffset=0;
for ii=1:param.pair
            for ind=ii:param.pair:neco
            spokes=double(param.undersampleSpokesTo);
            kdata_u(:,:,:,ind)=kdata(:,1+spokesOffset:spokes+spokesOffset,:,ind);  
            phi = [pi/2+spokesOffset*G_angle:G_angle:G_angle*spokes+spokesOffset*G_angle];
            k = (-nkx/2:nkx/2-1).' / nx / 2 .* exp(1i * phi); 
            k_u(:,:,ind)=k;
            w_u(:,:,ind)= radial_dcf_2d(k_u(:,:,ind)); % somewhere we should include a Hann or Hamming filter to suppress Gibbs-ringing. Maybe here?
            w_u(:,:,ind) = w_u(:,:,ind) .* hamming(nkx, 'periodic');
                fprintf('echo = %d\n', ind); 

            end
            spokesOffset=spokesOffset+param.undersampleSpokesTo;

end
      case 'Rotating'
   spokesOffset=nky-param.undersampleSpokesTo;
   spokes=double(param.undersampleSpokesTo);
   k_u= zeros(nkx,nky,ncha);
   w_u=zeros(size(k_u));
    phi  = zeros(nkx,nky,neco);
    par.blipangle= 0.0349;
for ip = 1:nky
    for ie = 1:neco
        phi(:,ip,ie) = pi/2 + (ip-1)*G_angle + (ie-1)*par.blipangle;
        k_u(:,ip,ie)=(-nkx/2:nkx/2-1).' / nx / 2 .* exp(1i * phi(:,ip,ie));
    end
end
for ii=1:neco
        w_u(:,:,ii)= radial_dcf_2d(k_u(:,:,ii)); % somewhere we should include a Hann or Hamming filter to suppress Gibbs-ringing. Maybe here?
        w_u(:,:,ii) = w_u(:,:,ii) .* hamming(nkx, 'periodic');
end

% We need to first have a fully sampled kspace with 2 degrees rotation so
% that we can undersample it 
kdata_i=zeros(nkx,nky,ncha,neco);
for echo=1:neco
  for coil = 1:ncha  
    param.E=MCNUFFT(double(k_u(:,:,echo)), double(w_u(:,:,echo)), ones(nx));    
    kdata_i(:, :, coil,echo) = param.E* (squeeze(double(Image(:, :, coil, echo)))) ;
    
  end
end
   kdata_i = kdata_i+randn(size(kdata_i))*param.snr + i*randn(size(kdata_i))*param.snr;
   kdata_u=kdata_i(:,1+spokesOffset:spokes+spokesOffset,:,:);  
   k_u=k_u(:,1+spokesOffset:spokes+spokesOffset,:);
   w_u= w_u(:,1+spokesOffset:spokes+spokesOffset,:);
end
 
% Just to test if its correct 
% kdata_i = permute(kdata_u, [1, 2, 4 3]); % NUFFT operator expects the time points / echos last?
% param.E=MCNUFFT(double(k_u), double(w_u), squeeze(sens_map(:,:,:,1)));
% 
% im_i = param.E'* (squeeze(double(kdata_u)) .* sqrt(w_u));


im_i=zeros(size(Image));
for echo=1:neco
  for coil = 1:ncha  
    param.E=MCNUFFT(double(k_u(:,:,echo)), double(w_u(:,:,echo)), ones(nx,ny,ncha));
    % this pre-density compensation is necessary because of the way the weights
    % are implemented in the MCNUFFT operator (again adjoint being the reason)
    im_i(:, :, coil,echo) = param.E'* squeeze(double(kdata_u(:, :, coil,echo))) ;
  end
   [~,sens_map(:,:,:,echo)]=adapt_array_2d(squeeze(im_i(:,:,:,echo)));
end
param.w=w_u;
param.k=k_u;

%  [param.z,sens_map]=initial_estimate(im_i,param);

as(im_i)

end
 

