function [mask, contourName] = contourToMask(pixelspc, position, dims, contours, contourIndex)
    
    xLim = position(2, 1) - pixelspc(2)/2 + [0, pixelspc(2) * dims(1)];
    yLim = position(1, 1) - pixelspc(1)/2 + [0, pixelspc(1) * dims(2)];
    zLim = position(3, 1) - pixelspc(3)/2 + [0, pixelspc(3) * dims(3)];
    
    referenceInfo = imref3d([dims(1), dims(2), dims(3)], yLim, xLim, zLim);
    
    mask = createMask(contours, contourIndex, referenceInfo);
    
    contourName = [];
    for n = 1:size(contours.ROIs, 1)
        if contours.ROIs.('Number')(n) == contourIndex
            contourName = contours.ROIs.('Name')(n);
        end
    end
    contourName = contourName{1};
        
end