function x = fista_sense2(param)

if ~isfield(param, 'nite'), param.nite = 5; end
if ~isfield(param, 'tol'), param.tol = 1e-4; end
if ~isfield(param, 'step'), param.step = 10; end
if ~isfield(param, 'GPU'), param.GPU = 0; end
if ~isfield(param, 'backtrack'), param.backtrack = 1; end
if ~isfield(param, 'step'), param.step = 10; end
if ~isfield(param, 'x0'), param.x0 = zeros(size(param.z)); end
max_iter = param.nite;
tol = param.tol;

[N,M,L] =  size(param.z);
step = param.step;
paramtv.useGPU=param.GPU;
paramtv.verbose = 0;

x = param.x0;
x2_prev = x;
obj_prev = 0;
%% FISTA for Wavelet L1

for i = 1:max_iter
    
    %Fx = F.forward(x);
    %err = (param.E*x - param.y);
    %err = norm(err(:))+ param.lambda*norm(x(:)-param.z(:));
    %err = Fx - y;
%     (param.E'*(param.y.*sqrt(param.w)))
    %grad1 =   F.adjoint(err) ;
%     grad1 = (param.E'*(param.E*x))+ param.lambda*x -  (param.E'*(param.y)) - param.lambda* param.z;
    grad1 = param.adjoint(param.forward(x)- param.y)+ param.lambda*x + param.lambda* param.z;
    
    %(param.E'*(param.E*x))+param.lambda*x -  (param.E'*param.y) - param.lambda* param.z;
    %cvxobj = 1/2*norm(err(:))^2 ;
    cvxobj = 1/2* norm(reshape(param.forward(x) - param.y,[],1))^2 + 1/2*param.lambda*norm(x(:)-param.z(:))^2;
    val = NORMTV2D(x);

    
    %---------backtracking line search
    done = 0;
    while ~done
        x2    =   x - grad1 * step;
        %[~,x2]=  wavethresh_group(x2, step*param.K);
        
        if param.TV>0
            x2 = proxTV2D(x2,step*param.TV);
        end
        
        %tmp = 1/2*(norm( reshape(F.forward(x2) - y,[],1))^2   +   rho* norm(x2(:)-z(:)+u(:))^2 );
        
        if ~ param.backtrack
            done = 1;
        else
            tmp = 1/2* norm(reshape(param.forward(x2) - param.y,[],1))^2 + 1/2*param.lambda*norm(x2(:)-param.z(:))^2;              %norm( reshape(F.forward(x2) - y,[],1))^2;
            if (tmp > cvxobj +  real( grad1(:)'*(x2(:)-x(:)))  + 1/(2*step) * norm(x2(:)-x(:))^2)
                disp('reducing stepsize...');
                step = step/2;
                if step < 1e-8, done=1; end
            else
                done = 1;
            end
        end
    end
    
    %----------------------
    obj = cvxobj + param.TV*val;
    fprintf('=== Iter=%i, Obj_FISTA: |y-Ax|^2  + beta*TV(x) + lambda*|x-z|  =%e\n', i,obj);
    
    if i>1 && ( abs(obj_prev-obj)/obj <tol || (obj_prev-obj)<0 ); break;end
    obj_prev = obj;
    
    %----------------------
    x     =   x2 + (i-1)/(i+2)* (x2-x2_prev);
    x2_prev = x2;
end


end
%==========useful functions (linked to unlocbox toolbox)
function x2=proxTV3D(x2,gamma)
%x2 = cat(4,real(x2),imag(x2));
dim = size(x2);
%x2  = cat(1,reshape(real(x2),dim(1),dim(2),[]), reshape(imag(x2),dim(1),dim(2),[]));
%x2  = cat(1,reshape((x2),dim(1),dim(2),[]));

paramtv.useGPU=1;
paramtv.verbose = 0;
for i=1:dim(4)
    x2(:,:,:,i) = prox_tv3d(x2(:,:,:,i), gamma, paramtv);
end
%x2 = x2(:,:,:,1:dim(4)/2) +1j*x2(:,:,:,dim(4)/2+1:end);
%x2 = reshape(x2,dim(1),dim(2),dim(3),[]);
end


function N=NORMTV3D(x2)
%x2 = cat(4,real(x2),imag(x2));
dim = size(x2);

N=0;
for i=1:dim(4)
    N=N+norm_tv3d(x2(:,:,:,i));
end

end

function x2=proxTV2D(x2,gamma)
dim = size(x2);

paramtv.useGPU=1;
paramtv.verbose = 0;
for i=1:dim(3)
    x2(:,:,i) = prox_tv(squeeze(x2(:,:,i)), gamma, paramtv);
end
end

function N=NORMTV2D(x2)
x2=(squeeze(x2));
dim = size(x2);

N=0;
for i=1:dim(3)
    N=N+norm_tv(x2(:,:,i));
end

end