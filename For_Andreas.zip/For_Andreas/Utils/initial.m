function z=initial_estimate(im_i,param);

TSE = zeros(param.nx, param.ny, param.neco/param.pair, param.ncha);
for e = 0:((NEco/param.pair)-1)
    TSE(:,:,e+1,:,:) = sum(im_i(:,:,(e*AF)+1:((e*AF)+AF),:,:),3);
end
% coil combine
TSE = sqrt(sum(TSE.*conj(TSE),5));
map = r2PixelFit(abs(TSE),param.TE);
param.M=map(:,:,2);
param.R=map(:,:,1);
for i=1:length(TE); z(:,:,i)=param.M.*exp(-TE(i).*param.R); end

end
