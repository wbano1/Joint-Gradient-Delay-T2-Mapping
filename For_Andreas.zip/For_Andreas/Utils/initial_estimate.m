function [z,b1]=initial_estimate(im_i,param)
TE=[10,30];
TSE = zeros(param.nx, param.ny, param.channel, param.echo/param.pair);
for e = 0:((param.echo/param.pair)-1)
    TSE(:,:,:,e+1) = sum(im_i(:,:,:,(e*param.pair)+1:((e*param.pair)+param.pair)),4);
end
% coil combine
[~,sens_map]=adapt_array_2d(squeeze(TSE(:,:,:,1)));
b1=repmat(sens_map,[1 1 1 param.echo]);
TSE = sqrt(sum(TSE.*conj(TSE),3));
map = r2PixelFit(abs(TSE),TE);
param.M=map(:,:,2);
param.R=map(:,:,1);
for i=1:length(param.TE); z(:,:,i)=param.M.*exp(-param.TE(i).*param.R); end

end
