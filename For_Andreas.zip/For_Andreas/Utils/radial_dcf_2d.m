function dcf_op = radial_dcf_2d(k)

dims = size(k);
samples = dims(1);

% ramlak = 2 * abs(((-dims(1)/2:dims(1)/2-1) + 0.5)) / (dims(1) - 1);
%if kr=0 falls on data point (not in between), use this one instead:
ramlak = abs((-samples/2):(samples/2-1)) / samples;
ramlak(samples/2+1) = 1 / 2 / samples;

angles = mod(angle(k(1, :)) + 2 * pi, 2 * pi);

% angular DCF:
[~, I] = sort(angles);

% angular weights based on distance to next sampled spokes ...
aweights(1:numel(I)) = mod(angles(I(mod(I, numel(I)) + 1)) ...
                         - angles(I(mod(I - 2 + numel(I), numel(I)) + 1)) + 2 * pi, 2 * pi) / 4 / pi;
        
dcf_op   = ramlak.' * aweights * samples * numel(angles) / dims(1);

