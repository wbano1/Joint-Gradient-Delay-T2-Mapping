function res = sos(x)
% sum of square along the third dimension
res = squeeze(sqrt(sum(abs(x).^2,4)));
