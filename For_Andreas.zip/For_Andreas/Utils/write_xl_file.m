function write_xl_file(Roi_data,name,sheet,filename)


f1=name';
% xlRange =['A','B','C','D','E','F','G','H','I'];
% myCellArray = cell(rows+1, size(Roi_data,2));

for contour=1: size(Roi_data,2)
    data= Roi_data{contour};
[rows , columns] = size(data);
myCellArray{1,contour} =['''',f1{contour} ] ; % First row has only this
% Now assign rows 2 and lower of our cell array.
        for col = 1
          for row = 1 : rows
            myCellArray{row+1, contour} = data(row, 1);
          end
        end
end
file_name= [filename,'.xlsx'];
%writetable(myCellArray,file_name, 'Sheet',sheet,'FileType','spreadsheet');
writecell(myCellArray,file_name, 'Sheet',sheet,'FileType','spreadsheet');
end
    
