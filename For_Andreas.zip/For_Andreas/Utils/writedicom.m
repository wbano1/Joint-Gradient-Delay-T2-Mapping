function writedicom(path,image)

inputfolder = path; 
% 'D:\DATA\5_Dec\GeRo\DICOM';
% here is where the T2map Dicom series will be exported
outputfolder = [path '\' 'T2'];

if ~exist(outputfolder, 'dir')
  mkdir(outputfolder);
end

list = dir(inputfolder);

% locations = [];

% b=1;
c=1;
% loading the Dicom headers for all files in the input folder (slow) and
% keeping the header for the first image found in each slice. (Needs the
% slice location tag to be present and assumes default order of files ...)
for a = 3:numel(list)
   info = dicominfo([inputfolder '/' list(a).name]);
  
%   data = dicomread([inputfolder '/' list(a).name]);
  gg='DelRec - multiecho 3DVane';
%   hh='T1_VTI';
     if (contains(info.SeriesDescription,gg))
            display(info.Filename);

%       (strcmp(info.SeriesDescription,gg))
%         T2(:,:,b)=dicomread([inputfolder '/' list(a).name]);
%               display(info.Filename);
% 
%     filename = [outputfolder2 '/' sprintf('%04d.dcm', c)];
%     dicomwrite(uint16(T2(:,:,b)), filename, info, 'CreateMode', 'Copy'); 
% 
%          b=b+1;

%   elseif (contains(info.SeriesDescription,hh))
%       display(info.Filename);
%       T1(:,:,c)=dicomread([inputfolder '/' list(a).name]);
%       T1(:, :,c) = info.RescaleIntercept + T1(:,:,c) .* info.RescaleSlope;
%       
    filename = [outputfolder '/' sprintf('%04d.dcm', c)];
 dicomwrite(uint16(image), filename, info, 'CreateMode', 'Copy'); 
 c=c+1;

    end

  %if ~any(TEs == info.EchoTime)
  %  TEs = [TEs info.EchoTime];
  %end
  
%   alldata(:, :, b) = double(data);
end
end
