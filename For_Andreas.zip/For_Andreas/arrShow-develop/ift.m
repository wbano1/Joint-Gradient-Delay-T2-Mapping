function fx=ift(x,varargin)

sz=size(x);
if isscalar(x)
  fx=x;
  return;
end

ns_dims=find(sz~=1);
first_ns_dim=ns_dims(1);
switch nargin
  case 1
    dim=first_ns_dim;
  case 2
    dim=varargin{1};
  otherwise
    dim=[varargin{:}];
end

if (isscalar(dim) && isnumeric(dim)&& dim==0) || (ischar(dim) && strcmpi(dim,'all'))
  dim=ns_dims;
  fx=fftshift(ifftn(ifftshift(x)))*sqrt(numel(x));
  return;
end

fx=x;
for k=dim
  fx=fftshift(ifft(ifftshift(fx,k),[],k),k)*sqrt(sz(k));
end



