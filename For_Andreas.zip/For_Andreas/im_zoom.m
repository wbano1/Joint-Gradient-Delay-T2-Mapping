
upperleft_pixel = [260, 214];  % position of uperleft corner pixel
box             = [75,  75];  % local window
zoomfactor      = 2;          % zoom factor
% I=n;

zoom_position   = 'ul';       % position: 'lr' = "lower_right", 'll' = 'lower_left', 'ur' = 'uper_right', 'ul' = 'uper_left' I   =   zoom_function(I, upperleft_pixel, box, zoomfactor, zoom_position);  I   =   zoom_function(I, upperleft_pixel, box, zoomfactor, zoom_position);
    I   =   zoom_function(n, upperleft_pixel, box, zoomfactor, zoom_position);
    imagesc(I(:,:,3),[0 90]),colormap jet, axis square
as(I(:,:,3));