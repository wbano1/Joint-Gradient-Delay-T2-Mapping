% Written by Kai Zhang,
% For further information, please contact: zhkmath@163.com
% More matlab codes can be found from: http://www.mathworks.com/matlabcentral/fileexchange/?term=authorid%3A635779
% My homepage is: https://sites.google.com/site/cskaizhang/home
%
% The code is used in the following paper:
%
% [1] Kai Zhang, Baoquan Wang, Wangmeng Zuo,  Hongzhi Zhang, and Lei Zhang, "Joint Learning of Multiple
% Regressors for Single Image Super-Resolution", to appear in IEEE SIGNAL PROCESSING LETTERS, 2016.

% [2] Zhang, Kai, et al. "Revisiting Single Image Super-Resolution Under Internet Environment: Blur Kernels
% and Reconstruction Algorithms." Advances in Multimedia Information Processing. Springer International
% Publishing, 2015. 677-687.
%
% Please cite the papers if you use this code.

input_folder    = 'baby';
output_folder   = [input_folder,'_zoom_results'];

upperleft_pixel = [72, 370]; % position of uperleft corner pixel
box             = [20,  20];
zoomfactor      = 8;
zoom_position   = 'ur'; % position: 'lr' = "lower_right", 'll' = 'lower_left', 'ur' = 'uper_right', 'ul' = 'uper_left'


upperleft_pixel2 = [413, 246]; % another position of uperleft corner pixel
box2             = [50,   40];
zoomfactor2      = 4;
zoom_position2   = 'lr'; % position: 'lr' = "lower_right", 'll' = 'lower_left', 'ur' = 'uper_right', 'ul' = 'uper_left'


if isdir(output_folder) == 0
    mkdir(output_folder);
end
ext             = {'*.jpg','*.png','*.bmp'};
images          = [];

for i = 1:length(ext)
    images = [images; dir(fullfile(input_folder, ext{i}))];
end

for i = 1:numel(images)
    [~, name, exte] = fileparts(images(i).name);
    I   =   imread( fullfile(input_folder,images(i).name) ) ;
    if i == 1
        imtool(double(I)/256)
    end
    
    I   =   zoom_function(I, upperleft_pixel, box, zoomfactor, zoom_position);
    I   =   zoom_function(I, upperleft_pixel2, box2, zoomfactor2, zoom_position2);
    
    imwrite(I, fullfile(output_folder,images(i).name), 'Compression','none');
    imshow(I)
    print('-depsc','-painters',fullfile(output_folder,[name,'.eps']));
    close;
end









