Author: 

Kai Zhang,
Harbin Institute of Technology, Harbin, China 

For further information, please contact: zhkmath@163.com
More matlab codes can be found from: http://www.mathworks.com/matlabcentral/fileexchange/?term=authorid%3A635779
My homepage is: https://sites.google.com/site/cskaizhang/home

The code is used in the following paper:

[1] Kai Zhang, Baoquan Wang, Wangmeng Zuo,  Hongzhi Zhang, and Lei Zhang, "Joint Learning of Multiple 
Regressors for Single Image Super-Resolution", to appear in IEEE SIGNAL PROCESSING LETTERS, 2016.

[2] Zhang, Kai, et al. "Revisiting Single Image Super-Resolution Under Internet Environment: Blur Kernels 
and Reconstruction Algorithms." Advances in Multimedia Information Processing. Springer International 
Publishing, 2015. 677-687.

Please cite the papers if you use this code. 


@incollection{zhang2015revisiting,
  title={Revisiting Single Image Super-Resolution Under Internet Environment: Blur Kernels and Reconstruction Algorithms},
  author={Zhang, Kai and Zhou, Xiaoyu and Zhang, Hongzhi and Zuo, Wangmeng},
  booktitle={Advances in Multimedia Information Processing--PCM 2015},
  pages={677--687},
  year={2015},
  publisher={Springer}
}



