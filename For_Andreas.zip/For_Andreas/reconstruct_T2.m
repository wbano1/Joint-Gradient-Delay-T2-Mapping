function T2maps = reconstruct_T2(folder)

%where the .list or .dat file is located

%load the data
data = loadRawKspacePhilips([folder '/raw_000.list']);

% raw data and image dimensions (according to .list file):
Nkx = abs(data.kspace_properties.kx_range(2) - data.kspace_properties.kx_range(1)) + 1;
Nky = abs(data.kspace_properties.ky_range(2) - data.kspace_properties.ky_range(1)) + 1;
Nkz = abs(data.kspace_properties.kz_range(2) - data.kspace_properties.kz_range(1)) + 1;
Nx = abs(data.kspace_properties.X_range(2) - data.kspace_properties.X_range(1)) + 1;
Ny = abs(data.kspace_properties.Y_range(2) - data.kspace_properties.Y_range(1)) + 1;
Nz = abs(data.kspace_properties.Z_range(2) - data.kspace_properties.Z_range(1)) + 1;
Nc  = numel(unique(data.chan));
Neco = data.kspace_properties.number_of_echoes; %WB

% load dicom data:
% [refvol, TEs, locs, pxdim] = loadMultiEchoDicomVolume([folder '\DICOM\IM_*'], 401);
% FOVx = (pxdim(1) * data.kspace_properties.X_resolution)/10;
% FOVy = pxdim(2) * data.kspace_properties.Y_resolution;
TEs=8;
locs=45;
FOVx = 40;
FOVy = 400;
% %DICOM/5 DelRec multiecho 3D Vane/DICOM/IM_*'
%  refvol = flip(refvol, 1); % so that orientation is correct
%  refvol = flip(refvol, 3); % to get the slice order right
% Nx=268;
% Ny=268;
% extract noise adjustment data:
noise = complex(zeros(numel(data.complexdata{find(cell2mat(data.typ) == 'NOI', 1)}), Nc));
for ii = 1:numel(data.complexdata)
    if strcmp(data.typ{ii}, 'NOI')
        noise(:, data.chan(ii) + 1) = data.complexdata{ii};
    end
end

% put raw data in more useful structure. ky index is problematic, we use the knowledge about the
% order in which k-space data is acquired:
raw = complex(zeros(Nkx, Nc, Nkz, Nky, data.kspace_properties.number_of_echoes));
ky_ind = 1;
for ii = 1:numel(data.complexdata)
    if strcmp(data.typ{ii}, 'STD')
       raw(:, data.chan(ii) + 1, data.kz(ii) - data.kspace_properties.kz_range(1) + 1, ...
           ky_ind, data.echo(ii) + 1) = data.complexdata{ii};
       if (data.echo(ii) == data.kspace_properties.number_of_echoes - 1) && (ii < numel(data.complexdata) - 1)
           if (data.ky(ii + 1) ~= data.ky(ii))
               ky_ind = ky_ind + 1;
           end
       end
    end
end
kspace_properties = data.kspace_properties;
% clear data ky_ind ii

% seems the length of the fft along z is given by the kz_oversample_factor:
FT_len = round(kspace_properties.Z_resolution * kspace_properties.kz_oversample_factor); %AW: this might imply an interpolation to thinner slices. Do you want that?

% bring raw data dimensions in more useful order [x c z y e] => [x y z c e]
raw = permute(raw, [1 4 3 2 5]);
% G_angle = pi * 2 / (1 + sqrt(5)); % is it simply golden angle or are we missing something? %WB
angle_increment = pi * 2 / (data.kspace_properties.ky_range(2) - data.kspace_properties.ky_range(1) + 1);
%% Acording to Andreas, the way to extract ky index
% ky = data.ky(Nc+1:end); % the first nc scans are noise adjustment scans
% % the first nc scans are noise adjustment scansky = reshape(ky, nc * nkz * ne, nky);
% par.ky = ky(1:(Nc*Neco):end, :); 
% That's what I do:
ky = data.ky(Nc+1:end); % the first nc scans are noise adjustment scans
ky = reshape(ky, Nc * Nkz * Neco, Nky);
par.ky = ky(1:(Nc*Neco):end, :); 
% so for me it is a matrix nkz * nky
%% generate Trajectory for Undersampling WB
spokesOffset=0;
param.pair=1;%For Fully Sampled put 1, For 2 times undersampling put 2, FOr 4 times put 4
param.undersampleSpokesTo=floor(Nky/param.pair);

kdata_u= complex(zeros(Nkx,param.undersampleSpokesTo,Nkz, Nc, Neco, 'single')); %AW: this only works because Neco = Nc, last index is echoes!
k_u= zeros(Nkx,param.undersampleSpokesTo,Nc);
w_u=zeros(size(k_u));    
% Andreas calculates k-space trajectory in different way
spokes=double(param.undersampleSpokesTo);
%     phi = [pi/2+spokesOffset*G_angle:G_angle:G_angle*spokes+spokesOffset*G_angle];
%      phi = [pi/2+spokesOffset*angle_increment :angle_increment :angle_increment*spokes+spokesOffset*angle_increment];
phi= double(par.ky(1,:)) * angle_increment + pi/2;
k = (-Nkx/2:Nkx/2-1).' / FOVy / 2 .* exp(1i * phi); % 2 is for readout oversampling ...
kdata_u=raw(:,1+spokesOffset:spokes+spokesOffset,:,:,:);
w = radial_dcf_2d(k); % somewhere we should include a Hann or Hamming filter to suppress Gibbs-ringing. Maybe here?
w_f = w .* hamming(Nkx, 'periodic');
knom=repmat(k,[1 1 8]);
w_u=repmat(w_f,[1 1 8]);


%% This is essantially for stack of stars 3D sequence
% perform FFT along z/kz, zerofilling
zf_raw = complex(zeros(Nkx, param.undersampleSpokesTo, FT_len, Nc, Neco));
zf_raw(:, :, floor(FT_len / 2) + 1 + (kspace_properties.kz_range(1):kspace_properties.kz_range(2)), :,:) = kdata_u;
zf_raw = ifft(ifftshift(zf_raw, 3), [], 3);

% remove oversampling in slice direction:
zf_raw = zf_raw(:, :, mod((kspace_properties.Z_range(1):kspace_properties.Z_range(2)) + FT_len, FT_len) + 1, :,:);
zf_raw = zf_raw(:, :, floor(size(zf_raw, 3) / 2) - floor(kspace_properties.Z_resolution / 2) + (1:kspace_properties.Z_resolution), :,:);
zf_raw = flip(zf_raw, 3);

%% Focus on first echo to get sensitivity maps 
knom(:,:,2:2:end)=knom(:,:,2:2:end)*-1;
k_u=knom.*FOVy./Nx;
% k_u(:,:,2:2:end)=k_u(:,:,2:2:end)*-1;
locs= 1:45;

param.E=MCNUFFT(double(k_u(:,:,1)), double(w_u(:,:,1)),ones(Nx));
% reconstruct first echo separately for each coil (otherwise MCNUFFT operator tries to
% combine the images ...)
recon = zeros(Nx,Ny,numel(locs),Nc); 

for kz = 1:numel(locs)
  for coil = 1:Nc
 
    % this pre-density compensation is necessary because of the way the weights
    % are implemented in the MCNUFFT operator (again adjoint being the reason)
    recon(:, :, kz,coil) = param.E'* (squeeze(double(zf_raw(:, :, kz,coil,1))) .* sqrt(w_u(:,:,1)));
    
  end
end

% recon = reshape(recon, Nx, Ny, size(zf_raw, 2) / Nc, Nc);
% as(recon)
% prompt = 'Please enter first slice number:'; % ask
% sl1 = input(prompt);
% prompt = 'Please enter first slice number:'; % ask
% sl2 = input(prompt);
%% trying some coil combination:
recon_comb = zeros(Nx, Ny, numel(locs));
b1 = zeros(Nx, Ny, numel(locs), Nc);

%rn = cov(noise);

% this takes far too long:
for z = 1:numel(locs)
  [recon_comb(:, :, z, :), b1(:, :, z, :)] = adapt_array_2d(squeeze(recon(:, :, z, :)));
end

%%
param.TE=5:5:40;
% slice=22;
% k_temp=knom;
% knom=k_u;
p.GPU=1;
%%
% Demo Trajectory Auto-Compensation Reconstruction (TrACR)for radial k-space trajectories
%=========================================================================================
% knom=param.k; % first echo only %BW
% knom(:,:,2:2:end)=knom(:,:,2:2:end)*-1;
% knom = knom / (size(knom, 1) / 2 / p.dim);
p.npts = size(knom,1); % number of points per radial line
p.nproj = size(knom,2); % number of radial projections
p.ncoils = size(zf_raw,4); % # Rx coils p.knom = [real(knom(:)) imag(knom(:))];   % nominal k-space trajectory form, cycles/cm [# points per projection x # projections]
p.echo=size(zf_raw,5);
% TrACR parameters---------------------------------------------------------
p.dim =512;     % matrix size, 1D (2nd assumed equal)
p.fov = 400;    % field of view in cm
% data=squeeze(kus(:,:,:,1)); % focussing on first echo WB
% p.data = reshape(data,[(p.npts*p.nproj),p.ncoils]);   % k-space data in: [(# readout pts * shots) X # coils]

% the k-space positions must be scaled according to the resolutions:
%knom = knom / (size(knom, 1) / 2 / p.dim); % two is for readout oversampling...
for i=1:p.echo
    temp=knom(:,:,i);
    p.knom(:,:,i) = [real(temp(:)) imag(temp(:))];
end
% nominal k-space trajectory form, cycles/cm [# points per projection x # projections]
% p.usedc = 1;     % use density compensation
p.maxiters = 100;  % maximum # of outer iterations to run TrACR
p.niteri = 2;    % # of iterations per image update
p.niterk = 5;    % # of iterations per kspace update
% p.imgcart = imgcart;    % Cartesian image from which to derive coil sensitivities
p.reconalg = 'SENSE'; % use SENSE image reconstruction (TrACR can also do SPIRiT if the correct parameters are passed)

p.useGPU =true; % AW_EDIT whether to use GG NUFFT or not ... 
p.useInitialGuess = true; % AW_EDIT whether to use non-zero initial guess ...
% [x, y] = ndgrid(-0.5:1/p.dim:0.5-0.5/p.dim);
  [x,y] = ndgrid(-p.fov/2:p.fov/p.dim:p.fov/2-p.fov/p.dim);
p.x = x(:);
p.y = y(:);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% set up k-space error basis (for radial)
% Assumption: The k-space errors comprise shifts of each line in kx-ky
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fprintf('Setting up error basis...\n');
eb = kron(speye(p.nproj),ones(p.npts,1));
p.eb = [eb 0*eb;0*eb eb]; % k-traj error basis (npts*nproj*(kx + ky) x nproj)


%run TrACR----------
%%%%%%%%%%%%%%%%%%%%%%%%%
p.wi=w_u;
param.lambda=0.5;
for slices= 1:45
 p.SENSEmap=squeeze(b1(:,:,slices,:));
kdata_i=squeeze(zf_raw(:,:,slices,:,:));
% [img_TrACR,c_TrACR,cost,imgsv,csv,p] = TrACR_sequential_odd_even_new(kdata_i,p);
[T2maps(:,:,slices), PD_TrACR_ALS,img_TrACR_ALS(:,:,slices,:),c_TrACR_ALS,cost,imgsv_t,csv,p_TrACR_ALS,param] = TrACR_ed_Will_GPU_odd_even(kdata_i,p,param);
% [T2_TrACR, PD_TrACR, img_TrACR]=log_lin(img_TrACR,param.TE);
end

% [T2_TrACR_ALS, PD_TrACR_ALS,img_TrACR_ALS,c_TrACR_ALS,cost,imgsv_t,csv,p_TrACR_ALS,param] = TrACR_ed_Will_GPU_odd_even(kdata_i,p,param);
filename='T2map.mat';
save([folder, '\' , filename ], '-v7.3');
 display_TrACR_result(p_TrACR_ALS,c_TrACR_ALS,imgsv_t,img_TrACR_ALS,cost)
end

