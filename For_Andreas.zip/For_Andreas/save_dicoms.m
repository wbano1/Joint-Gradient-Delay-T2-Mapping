function outputfolder = save_dicoms (folder, DICOM_folder, R2map)

%% Script to read T2* weighted DICOMS and write R2* Maps
% Settings:
% this folder should only contain the multiecho dicoms: 


% here is where the T2map Dicom series will be exported
outputfolder = [folder,'\','T2'];


% normalized = true => R2* is stored in integer values of 1/s without Rescale Intercept / Slope 
normalized = true;

% Start:

if ~exist(outputfolder, 'dir')
  mkdir(outputfolder);
end
list = dir(DICOM_folder);

locations = [];
TEs = [];

% loading the Dicom headers for all files in the input folder (slow) and
% keeping the header for the first image found in each slice. (Needs the
% slice location tag to be present and assumes default order of files ...)
for a = 3:numel(list)
   
  info = dicominfo([DICOM_folder '/' list(a).name]);
  
  data = dicomread([DICOM_folder '/' list(a).name]);
  
  if ~any(locations == info.SliceLocation)
    locations = [locations info.SliceLocation];
    headers(locations == info.SliceLocation).info = info;
  end
  
  if ~any(TEs == info.EchoTime)
   TEs = [TEs info.EchoTime];
  end
    info.SeriesInstanceUID=[info.SeriesInstanceUID,'.',info.EchoTime];
  alldata(:, :, locations == info.SliceLocation, TEs == info.EchoTime) = double(data);
    
end

[~, I] = sort(locations);
data_new = alldata(:, :, I, 8);
locations = locations(I);
headers = headers(I);

% need to create new SeriesInstanceUIDs:
ImplementationClassUID = '1.2.826.0.1.3680043.9.7185.3';
R2SeriesInstanceUID = [ImplementationClassUID '.1' datestr(now, '.yyyyMMddHHmmSSFFF')];
T2SeriesInstanceUID = [ImplementationClassUID '.2' datestr(now, '.yyyyMMddHHmmSSFFF')];

if normalized
  RescaleInterceptR2 = 0;
  RescaleSlopeR2 = 1;
else
  % for non-integer values, we need to use RescaleIntercept and RescaleSlope:
  RescaleInterceptR2 = min(R2map(:));
  RescaleSlopeR2 = (max(R2map(:)) - RescaleInterceptR2) / 4000;  
end


for a = 1:size(R2map,3)
    
   filename = [outputfolder '/' sprintf('%04d.dcm', a)];
   info = headers(a).info;

    display(info.SeriesDescription);
    
    % need to create new SOPInstanceUID:
    SOPInstanceUID = [ImplementationClassUID datestr(now, '.yyyyMMddHHmmSSFFF')];
    info.SOPInstanceUID = SOPInstanceUID;
    info.MediaStorageSOPInstanceUID = SOPInstanceUID;
    
    % assign new SeriesInstanceUID
    info.SeriesInstanceUID = R2SeriesInstanceUID;
    
    % assign new SeriesNumber & SeriesDescription
    info.SeriesNumber = info.SeriesNumber + 10;
    info.SeriesDescription = 'T2* map';
    
    % override rescale intercept and slope:
    info.RescaleIntercept = RescaleInterceptR2;
    info.RescaleSlope = RescaleSlopeR2;
    info.RescaleType = 'US';
    
    % so that it displays reasonably...
    info.WindowCenter = 20;
    info.WindowWidth = 40;
    info.PresentationLUTShape = 'IDENTITY';
  
    dicomwrite(uint16(round((R2map(:, :, a) - info.RescaleIntercept) / info.RescaleSlope)), filename, info, 'CreateMode', 'Copy'); 
%   slice=slice-1;
  
end
end
